import sqlite3
import pandas as pd
import datetime
import os  # 用于检查文件路径


class ZhihuDataImporter:
    def __init__(self, db_name='zhihu_campus_bullying.db'):
        """
        初始化数据库连接和创建表。
        :param db_name: 数据库文件的名称。
        """
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        print(f"成功连接到数据库: {db_name}")
        self._create_tables()

    def _create_tables(self):
        """
        创建posts和comments表（如果它们不存在）。
        """
        # 创建帖子表
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zhihu_id TEXT UNIQUE, -- 知乎平台上的ID
                url TEXT UNIQUE,      -- 帖子的URL
                title TEXT,
                content TEXT,
                type TEXT,
                crawl_time TEXT,      -- 爬取时间
                author TEXT,          -- 作者 (Excel中没有，可能为空)
                likes_count INTEGER,  -- 点赞数 (Excel中没有，可能为空)
                comments_count INTEGER -- 评论数 (Excel中没有，可能为空)
            )
        ''')
        print("表 'posts' 已检查/创建。")

        # 创建评论表 (如果未来您的Excel中有评论数据，可以用类似的方式导入)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                comment_id TEXT UNIQUE,
                post_url TEXT NOT NULL, -- 评论所属帖子的URL
                content TEXT,
                author TEXT,
                publish_time TEXT,
                parent_comment_id TEXT, -- 父评论的comment_id，用于表示回复关系
                likes_count INTEGER,
                crawl_time TEXT,
                FOREIGN KEY (post_url) REFERENCES posts(url) ON DELETE CASCADE
            )
        ''')
        print("表 'comments' 已检查/创建。")
        self.conn.commit()

    def insert_posts_from_excel(self, excel_file_path, sheet_name='Sheet1'):
        """
        从Excel文件中的指定工作表读取帖子数据并插入到posts表。
        :param excel_file_path: Excel文件的完整路径。
        :param sheet_name: 包含帖子数据的工作表名称，默认为'Sheet1'。
        """
        print(f"正在从 Excel 文件 '{excel_file_path}' 的 '{sheet_name}' 工作表读取帖子数据...")
        try:
            # 读取Excel数据
            df_posts = pd.read_excel(excel_file_path, sheet_name=sheet_name)
            print(f"成功读取 {len(df_posts)} 条数据。")

            # 清理列名，去除可能存在的空格等
            df_posts.columns = [col.strip().lower() for col in df_posts.columns]

            # 准备待插入的数据列表
            data_to_insert = []
            for index, row in df_posts.iterrows():
                # 确保所有预期的列都存在，如果不存在，则设置为None或默认值
                # Excel中没有的列，这里设置为None
                data_to_insert.append((
                    row.get('id'),  # 对应 zhihu_id
                    row.get('url'),
                    row.get('title'),
                    row.get('content'),
                    row.get('type'),
                    row.get('crawl_time'),  # 使用Excel中的爬取时间
                    None,  # author - Excel中没有，设为None
                    None,  # likes_count - Excel中没有，设为None
                    None  # comments_count - Excel中没有，设为None
                ))

            # 批量插入数据，使用 INSERT OR IGNORE 忽略重复的URL
            self.cursor.executemany('''
                INSERT OR IGNORE INTO posts (zhihu_id, url, title, content, type, crawl_time, author, likes_count, comments_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', data_to_insert)

            self.conn.commit()
            print(f"成功将 {self.cursor.rowcount} 条帖子数据导入到数据库。")

        except FileNotFoundError:
            print(f"错误：文件 '{excel_file_path}' 未找到。请检查路径和文件名。")
        except KeyError as e:
            print(f"错误：Excel文件中缺少必要的列，请检查工作表名称或列名。缺失列: {e}")
        except Exception as e:
            print(f"导入帖子数据时发生错误: {e}")

    # 您可以为导入评论数据添加类似的函数，如果未来有评论的Excel文件的话
    # def insert_comments_from_excel(self, excel_file_path, sheet_name='comments'):
    #     pass # 类似上述逻辑处理评论

    def close(self):
        """
        关闭数据库连接。
        """
        self.conn.close()
        print("数据库连接已关闭。")


# --- 主执行部分 ---
if __name__ == "__main__":
    # 确保Excel文件在Python脚本可以访问的位置
    # 'Path'在这里通常指脚本运行的当前目录。如果您有其他路径，请替换。
    excel_file_name = '知乎_校园霸凌_主题爬取结果_20250630_124328.xlsx'

    # 假设Excel文件和Python脚本在同一目录下
    # 如果不在同一目录，请提供完整路径，例如：
    # excel_file_path = r"C:\Your\Folder\知乎_校园霸凌_主题爬取结果_20250630_124328.xlsx"
    excel_file_path = os.path.join(os.getcwd(), excel_file_name)  # 获取当前工作目录并拼接文件名

    db_file_name = 'zhihu_campus_bullying.db'  # 数据库文件名

    importer = ZhihuDataImporter(db_file_name)

    try:
        # 导入帖子数据
        # 假设帖子数据在Excel的第一个或默认工作表（通常是'Sheet1'）
        # 如果您的数据在其他工作表，请更改 sheet_name 参数
        importer.insert_posts_from_excel(excel_file_path, sheet_name='Sheet1')

        # 如果您有评论数据，并且在Excel的另一个工作表，可以这样调用：
        # importer.insert_comments_from_excel(excel_file_path, sheet_name='comments_sheet')

    except Exception as e:
        print(f"执行数据导入过程中发生错误: {e}")
    finally:
        importer.close()

    print("数据导入数据库操作完成。请使用DB Browser for SQLite等工具查看数据库内容。")