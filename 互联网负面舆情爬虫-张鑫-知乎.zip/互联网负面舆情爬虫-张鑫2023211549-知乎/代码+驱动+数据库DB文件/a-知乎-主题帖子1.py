import os
import time
import pickle
import random
import re
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, \
    StaleElementReferenceException, WebDriverException
import pandas as pd  # 导入 pandas 库

# 配置
CHROME_DRIVER_PATH = 'chromedriver.exe'  # 或你的chromedriver实际路径
USER_DATA_DIR = r"D:\chrome_user_data"  # 用于记住登录
COOKIES_PATH = './zhihu_cookies.pkl'
TOPIC = '校园霸凌'
MAX_POSTS = 100
# EXCEL_PATH = 'zhihu_data.xlsx' # 定义Excel文件路径
EXCEL_PATH = f'知乎_{TOPIC}_爬取结果_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'


# --- 数据库操作函数 (可以保留但不会被使用，或根据需要删除) ---
# def init_db():
#     conn = sqlite3.connect(DB_PATH)
#     c = conn.cursor()
#     c.execute('''
#         CREATE TABLE IF NOT EXISTS posts (
#             id TEXT PRIMARY KEY,
#             url TEXT,
#             title TEXT,
#             content TEXT,
#             type TEXT,
#             crawl_time TEXT
#         )
#     ''')
#     c.execute('''
#         CREATE TABLE IF NOT EXISTS comments (
#             id TEXT PRIMARY KEY,
#             post_id TEXT,
#             parent_id TEXT,
#             content TEXT,
#             crawl_time TEXT
#         )
#     ''')
#     conn.commit()
#     conn.close()

# def insert_post(post):
#     # 此函数不再需要，数据将直接收集到列表中
#     pass

# def insert_comment(comment, post_id):
#     # 此函数不再需要，数据将直接收集到列表中
#     pass


# --- WebDriver 初始化和辅助函数（保持不变） ---
def init_driver():
    chrome_options = Options()
    chrome_options.add_argument(f'--user-data-dir={USER_DATA_DIR}')
    chrome_options.add_argument('--window-size=1200,900')

    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)

    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-browser-side-navigation")
    chrome_options.add_argument("--disable-features=VizDisplayCompositor")

    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

    service = Service(CHROME_DRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    return driver


def save_cookies(driver):
    try:
        with open(COOKIES_PATH, 'wb') as f:
            pickle.dump(driver.get_cookies(), f)
        print("Cookies saved successfully.")
    except Exception as e:
        print(f"Failed to save cookies: {e}")


def load_cookies(driver):
    if os.path.exists(COOKIES_PATH):
        driver.get('https://www.zhihu.com')
        try:
            with open(COOKIES_PATH, 'rb') as f:
                cookies = pickle.load(f)
            for cookie in cookies:
                # 确保cookie的域名与当前访问的域名兼容
                if 'domain' in cookie and 'zhihu.com' not in cookie['domain']:
                    continue
                try:
                    driver.add_cookie(cookie)
                except Exception as e:
                    # print(f"Error adding cookie {cookie}: {e}")
                    continue
            driver.refresh()
            time.sleep(2)
            print("Cookies loaded and refreshed.")
        except Exception as e:
            print(f"Failed to load cookies: {e}. Starting fresh login.")
            if os.path.exists(COOKIES_PATH):
                os.remove(COOKIES_PATH)
                print("Removed corrupted cookie file.")
    else:
        print("No cookies file found.")


def is_logged_in(driver):
    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, ".AppHeader-profileEntry, .TopNavBar-avatar, .Button.WriteAnswerButton"))
        )
        print("Detected logged in.")
        return True
    except TimeoutException:
        print("Detected not logged in or login check timed out.")
        return False
    except Exception as e:
        print(f"Error checking login status: {e}")
        return False


def manual_login(driver):
    print('请在弹出的浏览器中手动登录知乎，登录后按回车继续...')
    driver.get('https://www.zhihu.com')
    input("请在浏览器中完成登录，完成后回到此处按回车继续...")
    save_cookies(driver)
    if not is_logged_in(driver):
        print("警告：手动登录后未检测到登录成功，后续操作可能受影响。")


def human_behavior(driver):
    try:
        scroll_amount = random.randint(300, 900)
        driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
        time.sleep(random.uniform(1.5, 3.5))
    except WebDriverException as e:
        print(f"模拟人类行为失败: {e}. 可能是由于页面变化或元素不可交互。")
    except Exception as e:
        print(f"模拟人类行为失败: {e}")


def switch_to_tab(driver, tab_name):
    try:
        tab = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH,
                                        f"//div[contains(@class,'SearchTabs')]//button[contains(.,'{tab_name}')] | //div[contains(@class,'SearchTabs')]//a[contains(.,'{tab_name}')]"))
        )
        tab.click()
        print(f"Successfully switched to '{tab_name}' tab.")
        time.sleep(3)
        return True
    except TimeoutException:
        print(
            f"Timed out waiting for '{tab_name}' tab. Page structure may have changed or element not found. Skipping tab switch.")
        return False
    except Exception as e:
        print(f"Error switching to '{tab_name}' tab: {e}. Skipping tab switch.")
        return False


def search_topic(driver, topic):
    from urllib.parse import quote
    search_url = f"https://www.zhihu.com/search?q={quote(topic)}&type=content"
    print(f"Navigating to search URL: {search_url}")
    driver.get(search_url)
    time.sleep(5)


# --- get_posts 函数 (核心逻辑不变，只收集数据) ---
def get_posts(driver, max_posts):
    posts = []
    seen_urls = set()
    scroll_attempts = 0
    max_scroll_attempts = 50

    print(f"开始获取帖子，目标: {max_posts} 个...")

    while len(posts) < max_posts and scroll_attempts < max_scroll_attempts:
        print(f"当前已获取 {len(posts)} 个帖子，尝试滚动第 {scroll_attempts + 1} 次...")

        human_behavior(driver)

        item_selectors = [
            ".SearchResult-item",
            "div.List-item",
            "div[data-za-detail-view-path^='/question/'], div[data-za-detail-view-path^='/answer/'], div[data-za-detail-view-path^='/p/']",
            ".ContentItem",
        ]

        current_page_items = []
        for selector in item_selectors:
            try:
                elements = WebDriverWait(driver, 5).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, selector))
                )
                current_page_items.extend(elements)
            except TimeoutException:
                continue
            except StaleElementReferenceException:
                print("StaleElementReferenceException encountered during element re-finding.")
                continue
            except Exception as e:
                print(f"Error with selector '{selector}': {e}")
                continue

        unique_elements = []
        element_hashes = set()
        for elem in current_page_items:
            try:
                elem_hash = hash(elem.get_attribute("outerHTML"))
                if elem_hash not in element_hashes:
                    unique_elements.append(elem)
                    element_hashes.add(elem_hash)
            except StaleElementReferenceException:
                continue
            except Exception as e:
                print(f"Error hashing element: {e}")
                continue

        new_posts_added_this_scroll = 0
        for item in unique_elements:
            try:
                title_elem = None
                url_elem = None

                try:
                    title_elem = item.find_element(By.CSS_SELECTOR, "a[data-za-detail-view-path]")
                    url_elem = title_elem
                except NoSuchElementException:
                    try:
                        title_elem = item.find_element(By.CSS_SELECTOR, ".ContentItem-title a")
                        url_elem = title_elem
                    except NoSuchElementException:
                        try:
                            title_elem = item.find_element(By.CSS_SELECTOR,
                                                           "h2 a, .QuestionItem-title a, .ArticleItem-title a, .AnswerItem-title a")
                            url_elem = title_elem
                        except NoSuchElementException:
                            continue

                title = title_elem.text.strip() if title_elem else ""
                url = url_elem.get_attribute("href") if url_elem else ""

                post_id = None
                post_type = None

                if url and "zhihu.com" in url:
                    if "/question/" in url and "/answer/" not in url:
                        match = re.search(r'/question/(\d+)', url)
                        if match:
                            post_id = match.group(1)
                            post_type = "question"
                    elif "/answer/" in url:
                        match = re.search(r'/question/(\d+)/answer/(\d+)', url)
                        if match:
                            post_id = match.group(2)
                            post_type = "answer"
                    elif "/p/" in url:
                        match = re.search(r'/p/(\d+)', url)
                        if match:
                            post_id = match.group(1)
                            post_type = "article"

                if post_id and url not in seen_urls:
                    content = ""
                    try:
                        content_elem = item.find_element(By.CSS_SELECTOR, ".RichContent-inner, .SearchItem-metaText")
                        content = content_elem.text.strip()
                    except NoSuchElementException:
                        pass

                    posts.append({
                        'id': post_id,
                        'url': url,
                        'title': title,
                        'content': content,
                        'type': post_type,
                        'crawl_time': datetime.now().isoformat()  # 添加抓取时间
                    })
                    seen_urls.add(url)
                    new_posts_added_this_scroll += 1
                    if len(posts) >= max_posts:
                        break
            except StaleElementReferenceException:
                continue
            except Exception as e:
                continue

        if new_posts_added_this_scroll == 0 and scroll_attempts > 0:
            print("本轮滚动未发现新帖子，可能已达页面底部或已爬取全部。")
            break

        if len(posts) < max_posts:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(random.uniform(2.5, 4.0))
            scroll_attempts += 1
        else:
            break

    return posts


# --- 新增：获取评论函数（如果需要） ---
# 注意：评论抓取通常需要进入每个帖子详情页，这会大大增加爬取时间
# 且知乎评论加载机制可能更为复杂，可能涉及异步加载或嵌套评论
def get_comments(driver, post_url):
    print(f"    正在尝试获取评论: {post_url}")
    driver.get(post_url)
    time.sleep(random.uniform(3, 5))  # 等待页面加载
    human_behavior(driver)  # 在评论页也模拟滚动

    comments = []
    seen_comment_ids = set()  # 用于去重评论

    try:
        # 尝试找到“查看更多评论”或“展开评论”按钮并点击
        # 知乎评论区的CSS选择器经常变化，需要实地考察
        # 常见按钮有：.CommentList-footer button, .CommentListV2-footer .Button
        # 可能还需要点击“展开回复”等

        # 尝试加载所有评论
        load_more_attempts = 0
        max_load_more_attempts = 10  # 限制加载更多评论的尝试次数

        while load_more_attempts < max_load_more_attempts:
            try:
                # 寻找“查看更多回复”或“加载更多评论”按钮
                load_more_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH,
                                                "//button[contains(.,'查看更多回复') or contains(.,'加载更多评论') or contains(.,'展开更多')]"))
                )
                driver.execute_script("arguments[0].click();", load_more_button)  # 使用JS点击更稳定
                time.sleep(random.uniform(1.5, 2.5))  # 等待新评论加载
                human_behavior(driver)  # 模拟行为，帮助加载
                load_more_attempts += 1
            except TimeoutException:
                # print("      未找到加载更多评论按钮或已加载完全部评论。")
                break  # 如果超时，认为没有更多评论按钮了
            except StaleElementReferenceException:
                print("      StaleElementReferenceException while loading more comments, trying again.")
                continue  # 元素失效，再试一次
            except Exception as e:
                # print(f"      加载更多评论按钮点击失败: {e}")
                break  # 其他错误也退出循环

        # 抓取所有可见的评论项
        # 评论项的CSS选择器也需要频繁更新
        # 常见评论项：.CommentItem, .CommentItemV2, .CommentsV2-item
        comment_item_selectors = [
            ".CommentItem",
            ".CommentItemV2",
            ".CommentsV2-item",
            "div[data-comment-id]"  # 通常评论会有这个属性
        ]

        current_comments_elements = []
        for selector in comment_item_selectors:
            try:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
                current_comments_elements.extend(elements)
            except Exception:
                continue

        for item in current_comments_elements:
            try:
                comment_id = item.get_attribute("data-comment-id") or item.get_attribute("id")
                if not comment_id or comment_id in seen_comment_ids:
                    continue  # 去重

                content_elem = item.find_element(By.CSS_SELECTOR,
                                                 ".CommentItemV2-content, .CommentItem-content, .CommentsV2-content")
                content = content_elem.text.strip() if content_elem else ""

                parent_id = item.get_attribute("data-parent-id")  # 用于回复评论

                comments.append({'id': comment_id, 'content': content, 'parent_id': parent_id})
                seen_comment_ids.add(comment_id)
            except NoSuchElementException:
                continue  # 没有找到内容元素，跳过
            except StaleElementReferenceException:
                continue  # 元素失效，跳过
            except Exception as e:
                print(f"      处理评论项失败: {e}")
                continue
    except Exception as e:
        print(f"    获取评论过程中发生错误: {e}")

    return comments


# --- 主函数 ---
def main():
    # init_db() # 不再需要初始化数据库

    # 用于收集所有帖子和评论数据
    all_posts_data = []
    all_comments_data = []  # 如果需要收集评论，解除get_comments的注释

    driver = None
    try:
        driver = init_driver()
        load_cookies(driver)
        if not is_logged_in(driver):
            manual_login(driver)

        search_topic(driver, TOPIC)

        # 这一步通常在直接指定URL参数时不是必须的，并且可能因页面结构变化而失败
        # 如果您确定页面结构稳定且需要点击Tab，再取消注释并检查选择器
        # if not switch_to_tab(driver, '内容'):
        #     switch_to_tab(driver, '综合')

        posts = get_posts(driver, MAX_POSTS)
        print(f'\n--- 共获取到 {len(posts)} 个帖子 ---')

        for idx, post in enumerate(posts, 1):
            print(f'[{idx}/{len(posts)}] 类型: {post["type"]}, 标题: {post["title"]}')
            all_posts_data.append(post)  # 将帖子数据添加到列表中

            # 如果需要抓取评论，请取消注释以下代码块
            # comments = get_comments(driver, post['url'])
            # print(f'  评论数: {len(comments)}')
            # for comment in comments:
            #     # 为评论添加post_id和crawl_time
            #     comment['post_id'] = post['id']
            #     comment['crawl_time'] = datetime.now().isoformat()
            #     all_comments_data.append(comment) # 将评论数据添加到列表中

            time.sleep(random.uniform(1, 3))  # 每次处理完一个帖子后短暂等待

        # 将收集到的数据写入Excel
        if all_posts_data:
            posts_df = pd.DataFrame(all_posts_data)
            # 保存到Excel，一个sheet
            with pd.ExcelWriter(EXCEL_PATH, engine='xlsxwriter') as writer:
                posts_df.to_excel(writer, sheet_name='Posts', index=False)
                if all_comments_data:
                    comments_df = pd.DataFrame(all_comments_data)
                    comments_df.to_excel(writer, sheet_name='Comments', index=False)
            print(f'\n所有数据已成功保存到 {EXCEL_PATH}')
        else:
            print("\n没有爬取到任何帖子，未生成Excel文件。")

    except Exception as e:
        print(f"主程序运行发生错误: {e}")
    finally:
        if driver:
            driver.quit()
            print("\n浏览器已关闭。")


if __name__ == '__main__':
    main()