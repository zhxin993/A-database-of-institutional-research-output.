import pandas as pd
import jieba # 假设你需要分词
import re    # 假设你需要正则表达式匹配
from collections import Counter # 导入 Counter 用于词频统计
import matplotlib.pyplot as plt # 导入 matplotlib 用于可视化
import seaborn as sns # 导入 seaborn，让图表更美观

# 设置Matplotlib支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei'] # 或者选择你系统中存在的其他中文字体，如 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False # 解决负号显示问题

# 假设你的文件在项目根目录或者你可以提供完整路径
file_path = '知乎_校园霸凌_主题爬取结果_20250630_124328.xlsx'

df = None # 先初始化 df 为 None，以防万一

try:
    df = pd.read_excel(file_path)
    print("数据加载成功！")
    print(f"数据总条数：{len(df)}")
    print("数据前5行：")
    print(df.head())
    print("所有列名：", df.columns.tolist()) # 确认列名已获取
except FileNotFoundError:
    print(f"错误：文件 '{file_path}' 未找到。请检查文件路径是否正确。")
    exit() # 文件未找到，直接退出程序
except Exception as e:
    print(f"加载文件时发生错误：{e}")
    print("请确保已安装 'openpyxl' 库：pip install openpyxl")
    exit() # 其他加载错误，也退出程序

# 在这里添加一个检查，确保 df 已经被成功加载
if df is None or df.empty:
    print("错误：数据框 df 未成功加载或为空，无法继续执行。")
    exit()

# === 关键词表：请确保每个列表不少于50个词，这里已经扩充过，但你仍需检查并完善 ===
keywords = {
    '涉政有害': [
        '政治敏感', '煽动', '非法组织', '分裂', '颠覆', '恐怖', '邪教', '极端',
        '抵制', '反动', '谣言', '虚假信息', '意识形态', '社会秩序', '国家安全', '境外势力',
        '敏感事件', '政治运动', '冲突', '煽动仇恨', '非法集会', '游行示威', '政治迫害',
        '政治腐败', '贪污', '腐败分子', '国家机密', '泄密', '非法武装', '颠覆国家政权',
        '分裂国家', '恐怖袭击', '恐怖主义', '煽动暴力', '虚假宣传', '反人类', '叛国',
        '反华', '反政府', '挑衅', '干涉内政', '非法言论', '颠覆性', '反动派', '反革命',
        '政治阴谋', '煽动分裂', '非法结社', '非法集资', '扰乱秩序', '破坏稳定', '国家安全威胁',
        '渗透', '策反', '政治审查', '政治迫害', '政治犯', '政治阴谋论', '非法示威',
        '非法煽动', '煽动群众', '非法传销', '非法出版物', '非法音像制品', '非法网络活动',
        # ... 已经有65个词，满足要求，如有需要可继续添加
    ],
    '侮辱谩骂': [
        '脏话', '傻逼', '白痴', '垃圾', '废物', '智障', '蠢货', '滚蛋', '去死', '你妈',
        '神经病', '脑残', '无耻', '下贱', '恶心', '变态', '贱人', '狗屎', '渣滓', '流氓',
        '畜生', '禽兽', '杂种', '狗杂种', '烂货', '泼妇', '小人', '卑鄙', '下流', '无赖',
        '混蛋', '龟儿子', '王八蛋', '饭桶', '废物点心', '臭狗屎', '烂人', '狗东西', '瞎了眼',
        '没脑子', '蠢蛋', '笨蛋', '呆子', '二百五', '傻瓜', '笨瓜', '恶棍', '痞子', '流氓地痞',
        '恶毒', '歹毒', '下三滥', '无赖', '人渣', '垃圾人', '疯子', '疯狗', '神经病', '精神病',
        '祸害', '祸水', '败类', '孽障', '诅咒', '去你妈的', '草泥马', '傻逼', '蠢货', '白痴'
        # ... 已经有69个词，满足要求，如有需要可继续添加
    ],
    '色情暴力': [
        '色情', '淫秽', '黄色', '性侵', '强奸', '裸照', '暴露', '性交易', 'AV', '淫乱',
        '暴力', '血腥', '打架', '殴打', '杀人', '肢解', '虐待', '自残', '残忍', '血案',
        '强暴', '性骚扰', '性暴力', '淫荡', '卖淫', '嫖娼', '裸露', '诱惑', '色诱', '淫秽物品',
        '枪击', '砍杀', '殴打', '施暴', '暴力事件', '血腥场面', '凶杀', '凶残', '惨无人道',
        '自杀', '自残行为', '虐待动物', '儿童色情', '非法色情', '传播淫秽', '暴力视频',
        '血腥暴力', '校园暴力', '家庭暴力', '性剥削', '淫秽网站', '强迫性交', '性奴',
        '性虐待', '裸体', '性爱', '色诱', '暴力犯罪', '凶器', '致死', '伤害', '攻击',
        '威胁', '绑架', '勒索', '性幻想', '性暗示', '强迫', '性丑闻', '奸淫'
        # ... 已经有70个词，满足要求，如有需要可继续添加
    ],
    '事故灾难': [
        '事故', '灾难', '火灾', '地震', '洪水', '坍塌', '爆炸', '坠机', '沉船', '车祸',
        '疫情', '病毒', '死亡', '受伤', '失踪', '救援', '损失', '破坏', '不幸', '倒塌',
        '空难', '矿难', '泥石流', '山体滑坡', '雪崩', '海啸', '飓风', '龙卷风', '暴雨',
        '干旱', '疫病', '饥荒', '饥饿', '中毒', '污染', '核泄漏', '工业事故', '建筑事故',
        '桥梁坍塌', '交通瘫痪', '停电', '停水', '物资匮乏', '受灾', '受难', '灾民', '紧急状态',
        '封锁', '隔离', '感染', '病危', '死亡人数', '伤亡', '逃生', '抢险', '灾后重建',
        '灾情', '灾变', '崩塌', '爆裂', '失事', '遇难', '牺牲', '被困', '瓦斯爆炸', '踩踏'
        # ... 已经有66个词，满足要求，如有需要可继续添加
    ],
    '聚焦维权': [
        '维权', '投诉', '举报', '曝光', '欺诈', '侵权', '合同纠纷', '劳务纠纷', '消费者权益',
        '不公平', '不合理', '讨说法', '声讨', '求助', '申诉', '上访', '集体诉讼', '律师函',
        '诈骗', '非法集资', '欠薪', '克扣', '压榨', '剥削', '歧视', '霸凌', '不法行为',
        '权益受损', '利益受损', '损害', '纠纷', '争端', '抗议', '罢工', '游行', '示威',
        '请愿', '联名', '告状', '打官司', '法律援助', '媒体曝光', '舆论监督', '正义',
        '公平', '公正', '补偿', '赔偿', '赔款', '索赔', '追责', '问责', '不作为', '乱作为',
        '滥用职权', '非法拆迁', '强行', '霸占', '私吞', '截留', '克扣', '虚假宣传', '质量问题'
        # ... 已经有63个词，满足要求，如有需要可继续添加
    ],
    '娱乐八卦': [ # 注意这里的负面倾向
        '绯闻', '丑闻', '出轨', '吸毒', '假唱', '炒作', '黑料', '塌房', '解约', '被捕',
        '负面新闻', '争议', '内幕', '爆料', '撕逼', '人设崩塌', '退圈', '凉凉', '官宣',
        '潜规则', '整容失败', '耍大牌', '票房造假', '刷流量', '偷税漏税', '违法', '被封杀',
        '分手', '离婚', '撕破脸', '对骂', '不和', '失言', '失德', '争议言论', '洗白',
        '炒作恋情', '私生活混乱', '被拍', '私生饭', '狗仔队', '爆隐私', '诽谤', '造谣',
        '黑粉', '脱粉', '退圈声明', '丑闻缠身', '口碑下滑', '事业危机', '星途黯淡', '风评被害',
        '水军', '控评', '买热搜', '蹭热度', '捆绑销售', '虚假人设', '人设崩坏', '翻车'
        # ... 已经有60个词，满足要求，如有需要可继续添加
    ]
}


# 检查每个词表的长度
for category, kw_list in keywords.items():
    print(f"'{category}' 关键词数量: {len(kw_list)}")
    if len(kw_list) < 50:
        print(f"警告：'{category}' 关键词数量不足50个，请继续补充。")

# === 修改这里：使用你提供的正确列名 'content' ===
content_column = 'content' # 或者 '帖子内容', '评论内容' 等

# 初始化一个新的列来存储负面主题
df['负面主题'] = ''
df['是否负面'] = False

# 遍历每个负面主题和其关键词
for category, kw_list in keywords.items():
    pattern = '|'.join([re.escape(kw) for kw in kw_list])

    # 优化：使用 apply 函数可以更高效地处理
    # 使用 lambda 函数和 apply 方法检查每行内容是否匹配模式
    # 这里我们使用一个临时的 Series 来存储当前类别的匹配结果
    matches = df[content_column].astype(str).apply(lambda x: bool(re.search(pattern, x, re.IGNORECASE)))

    # 将匹配到的行更新到 '负面主题' 列
    # 对于首次匹配到的主题，直接赋值；对于后续匹配到的主题，追加
    for index, match in matches.items():
        if match:
            if df.at[index, '负面主题']:
                # 避免重复添加同一个主题，如果已经存在则跳过
                if category not in df.at[index, '负面主题'].split(';'):
                    df.at[index, '负面主题'] += f";{category}"
            else:
                df.at[index, '负面主题'] = category
            df.at[index, '是否负面'] = True


print("\n负面文本筛选完成！")
print("筛选结果示例 (前10行，包含负面主题信息):")
print(df[df['是否负面'] == True].head(10)[[content_column, '负面主题']])

# 筛选出所有负面文本
negative_texts_df = df[df['是否负面'] == True].copy()
print(f"\n共筛选出 {len(negative_texts_df)} 条负面文本。")

# 保存筛选结果 (可选)
# output_file_path = '知乎_校园霸凌_负面舆情_筛选结果.xlsx'
# negative_texts_df.to_excel(output_file_path, index=False)
# print(f"负面文本筛选结果已保存到 '{output_file_path}'")

# --- 负面主题分布统计与可视化 ---
print("\n负面主题分布统计：")
if not negative_texts_df.empty:
    all_negative_topics = negative_texts_df['负面主题'].str.split(';').explode()
    topic_counts = all_negative_topics.value_counts()
    print(topic_counts)

    # 可视化：负面主题分类柱状图
    plt.figure(figsize=(10, 6))
    sns.barplot(x=topic_counts.index, y=topic_counts.values, palette='viridis')
    plt.title('知乎“校园霸凌”负面舆情主题分布')
    plt.xlabel('负面主题')
    plt.ylabel('文本数量')
    plt.xticks(rotation=45, ha='right') # 旋转x轴标签，防止重叠
    plt.tight_layout() # 调整布局，防止标签重叠
    plt.savefig('negative_topic_distribution.png') # 保存图表
    plt.show() # 显示图表
else:
    print("没有负面文本，无法进行主题分布统计和可视化。")

# --- 负面文本总量与百分比 ---
total_negative_count = len(negative_texts_df)
print(f"\n总负面文本数量：{total_negative_count}")
total_posts = len(df)
negative_percentage = (total_negative_count / total_posts) * 100 if total_posts > 0 else 0
print(f"负面文本占总文本的百分比：{negative_percentage:.2f}%")

# 可视化：整体舆情倾向饼图 (假设存在非负面文本)
# 这里我们创建一个假想的“非负面”类别来形成饼图
non_negative_count = total_posts - total_negative_count
sentiment_counts = pd.Series({'负面': total_negative_count, '非负面': non_negative_count})
if total_posts > 0: # 只有当有数据时才绘制饼图
    plt.figure(figsize=(8, 8))
    plt.pie(sentiment_counts, labels=sentiment_counts.index, autopct='%1.1f%%', startangle=90, colors=['#ff9999','#66b3ff'])
    plt.title('知乎“校园霸凌”主题舆情倾向分布')
    plt.axis('equal') # 使饼图为圆形
    plt.savefig('overall_sentiment_pie_chart.png') # 保存图表
    plt.show() # 显示图表
else:
    print("没有数据，无法绘制整体舆情倾向饼图。")


# --- 深入分析示例 (自由探索部分) ---
print("\n--- 深入分析示例 (自由探索部分) ---")

# 示例：针对“侮辱谩骂”主题，看看有哪些高频词
if not negative_texts_df.empty:
    insult_texts = negative_texts_df[negative_texts_df['负面主题'].str.contains('侮辱谩骂', na=False)]
    if not insult_texts.empty:
        all_words_in_insult = []
        for text in insult_texts[content_column]:
            all_words_in_insult.extend(jieba.lcut(text)) # 使用jieba分词

        # 过滤掉停用词和单个字符
        stop_words = ['的', '了', '是', '我', '你', '他', '她', '它', '我们', '你们', '他们', '她们', '它们',
                      '和', '与', '或', '但', '而', '所以', '因为', '如果', '就', '也', '都', '很', '非常',
                      '一个', '这种', '那样', '这个', '那个', '什么', '怎么', '多少', '哪里', '什么时候',
                      '？', '！', '。', '，', '、', '；', '：', '“', '”', '‘', '’', '（', '）', '《', '》',
                      '=', '-', '+', '*', '/', '\\', '|', '~', '`', '!', '@', '#', '$', '%', '^', '&',
                      '(', ')', '_', '{', '}', '[', ']', ':', ';', '<', '>', ',', '.', '?', '/', '<', '>',
                      '\'', '\"', ' ']
        filtered_words = [
            word for word in all_words_in_insult
            if len(word) > 1 and word.strip() and word not in stop_words and not word.isdigit()
        ]
        word_freq = Counter(filtered_words)
        print("\n'侮辱谩骂' 类别中高频词汇 (前10):")
        top_words = word_freq.most_common(10)
        print(top_words)

        # 可视化：侮辱谩骂类高频词汇柱状图
        if top_words:
            words, counts = zip(*top_words)
            plt.figure(figsize=(10, 6))
            sns.barplot(x=list(words), y=list(counts), palette='coolwarm')
            plt.title('“侮辱谩骂”类高频词汇分布')
            plt.xlabel('词汇')
            plt.ylabel('出现次数')
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            plt.savefig('insult_high_frequency_words.png')
            plt.show()

    else:
        print("\n没有找到 '侮辱谩骂' 相关的负面文本。")
else:
    print("\n没有负面文本可供进一步分析。")

print("\n请根据以上统计和分析结果，在你的报告中进行详细的讨论。")