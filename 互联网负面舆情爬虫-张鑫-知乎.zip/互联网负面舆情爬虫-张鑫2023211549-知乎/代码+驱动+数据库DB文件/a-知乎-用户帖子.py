import os
import time
import pickle
import random
import re
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, \
    StaleElementReferenceException, WebDriverException
import pandas as pd  # 导入 pandas 库

# 配置
CHROME_DRIVER_PATH = 'chromedriver.exe'  # 或你的chromedriver实际路径
USER_DATA_DIR = r"D:\chrome_user_data"  # 用于记住登录
COOKIES_PATH = './zhihu_cookies.pkl'
TOPIC = '校园霸凌'
MAX_POSTS = 100
# EXCEL_PATH = 'zhihu_data.xlsx' # 定义Excel文件路径
EXCEL_PATH = f'知乎_{TOPIC}_爬取结果_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'


# --- 数据库操作函数 (可以保留但不会被使用，或根据需要删除) ---
# def init_db():
#     conn = sqlite3.connect(DB_PATH)
#     c = conn.cursor()
#     c.execute('''
#         CREATE TABLE IF NOT EXISTS posts (
#             id TEXT PRIMARY KEY,
#             url TEXT,
#             title TEXT,
#             content TEXT,
#             type TEXT,
#             crawl_time TEXT
#         )
#     ''')
#     c.execute('''
#         CREATE TABLE IF NOT EXISTS comments (
#             id TEXT PRIMARY KEY,
#             post_id TEXT,
#             parent_id TEXT,
#             content TEXT,
#             crawl_time TEXT
#         )
#     ''')
#     conn.commit()
#     conn.close()

# def insert_post(post):
#     # 此函数不再需要，数据将直接收集到列表中
#     pass

# def insert_comment(comment, post_id):
#     # 此函数不再需要，数据将直接收集到列表中
#     pass


# --- WebDriver 初始化和辅助函数（保持不变） ---
def init_driver():
    chrome_options = Options()
    chrome_options.add_argument(f'--user-data-dir={USER_DATA_DIR}')
    chrome_options.add_argument('--window-size=1200,900')

    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)

    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-browser-side-navigation")
    chrome_options.add_argument("--disable-features=VizDisplayCompositor")

    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

    service = Service(CHROME_DRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    return driver


def save_cookies(driver):
    try:
        with open(COOKIES_PATH, 'wb') as f:
            pickle.dump(driver.get_cookies(), f)
        print("Cookies saved successfully.")
    except Exception as e:
        print(f"Failed to save cookies: {e}")


def load_cookies(driver):
    if os.path.exists(COOKIES_PATH):
        driver.get('https://www.zhihu.com')
        try:
            with open(COOKIES_PATH, 'rb') as f:
                cookies = pickle.load(f)
            for cookie in cookies:
                # 确保cookie的域名与当前访问的域名兼容
                if 'domain' in cookie and 'zhihu.com' not in cookie['domain']:
                    continue
                try:
                    driver.add_cookie(cookie)
                except Exception as e:
                    # print(f"Error adding cookie {cookie}: {e}")
                    continue
            driver.refresh()
            time.sleep(2)
            print("Cookies loaded and refreshed.")
        except Exception as e:
            print(f"Failed to load cookies: {e}. Starting fresh login.")
            if os.path.exists(COOKIES_PATH):
                os.remove(COOKIES_PATH)
                print("Removed corrupted cookie file.")
    else:
        print("No cookies file found.")


def is_logged_in(driver):
    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, ".AppHeader-profileEntry, .TopNavBar-avatar, .Button.WriteAnswerButton"))
        )
        print("Detected logged in.")
        return True
    except TimeoutException:
        print("Detected not logged in or login check timed out.")
        return False
    except Exception as e:
        print(f"Error checking login status: {e}")
        return False


def manual_login(driver):
    print('请在弹出的浏览器中手动登录知乎，登录后按回车继续...')
    driver.get('https://www.zhihu.com')
    input("请在浏览器中完成登录，完成后回到此处按回车继续...")
    save_cookies(driver)
    if not is_logged_in(driver):
        print("警告：手动登录后未检测到登录成功，后续操作可能受影响。")


def human_behavior(driver):
    try:
        scroll_amount = random.randint(300, 900)
        driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
        time.sleep(random.uniform(1.5, 3.5))
    except WebDriverException as e:
        print(f"模拟人类行为失败: {e}. 可能是由于页面变化或元素不可交互。")
    except Exception as e:
        print(f"模拟人类行为失败: {e}")


def switch_to_tab(driver, tab_name):
    try:
        tab = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH,
                                        f"//div[contains(@class,'SearchTabs')]//button[contains(.,'{tab_name}')] | //div[contains(@class,'SearchTabs')]//a[contains(.,'{tab_name}')]"))
        )
        tab.click()
        print(f"Successfully switched to '{tab_name}' tab.")
        time.sleep(3)
        return True
    except TimeoutException:
        print(
            f"Timed out waiting for '{tab_name}' tab. Page structure may have changed or element not found. Skipping tab switch.")
        return False
    except Exception as e:
        print(f"Error switching to '{tab_name}' tab: {e}. Skipping tab switch.")
        return False


def search_topic(driver, topic):
    from urllib.parse import quote
    search_url = f"https://www.zhihu.com/search?q={quote(topic)}&type=content"
    print(f"Navigating to search URL: {search_url}")
    driver.get(search_url)
    time.sleep(5)


def get_user_posts(driver, user_slug, max_posts=100):
    posts = []
    seen_urls = set()
    scroll_attempts = 0
    max_scroll_attempts = 50

    # 进入用户主页的“内容”页
    url = f"https://www.zhihu.com/people/{user_slug}/answers"
    print(f"访问用户主页: {url}")
    driver.get(url)
    time.sleep(5)

    while len(posts) < max_posts and scroll_attempts < max_scroll_attempts:
        print(f"当前已获取 {len(posts)} 个帖子，尝试滚动第 {scroll_attempts + 1} 次...")

        human_behavior(driver)

        # 回答/文章的选择器
        item_selectors = [
            ".List-item",  # 回答/文章
            ".ContentItem",
            "div[data-za-detail-view-path^='/question/'], div[data-za-detail-view-path^='/answer/'], div[data-za-detail-view-path^='/p/']"
        ]

        current_page_items = []
        for selector in item_selectors:
            try:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
                current_page_items.extend(elements)
            except Exception:
                continue

        unique_elements = []
        element_hashes = set()
        for elem in current_page_items:
            try:
                elem_hash = hash(elem.get_attribute("outerHTML"))
                if elem_hash not in element_hashes:
                    unique_elements.append(elem)
                    element_hashes.add(elem_hash)
            except Exception:
                continue

        new_posts_added_this_scroll = 0
        for item in unique_elements:
            try:
                title_elem = None
                url_elem = None

                try:
                    title_elem = item.find_element(By.CSS_SELECTOR, "a[data-za-detail-view-path]")
                    url_elem = title_elem
                except NoSuchElementException:
                    try:
                        title_elem = item.find_element(By.CSS_SELECTOR, ".ContentItem-title a")
                        url_elem = title_elem
                    except NoSuchElementException:
                        continue

                title = title_elem.text.strip() if title_elem else ""
                url = url_elem.get_attribute("href") if url_elem else ""

                post_id = None
                post_type = None

                if url and "zhihu.com" in url:
                    if "/question/" in url and "/answer/" in url:
                        match = re.search(r'/question/(\d+)/answer/(\d+)', url)
                        if match:
                            post_id = match.group(2)
                            post_type = "answer"
                    elif "/p/" in url:
                        match = re.search(r'/p/(\d+)', url)
                        if match:
                            post_id = match.group(1)
                            post_type = "article"

                if post_id and url not in seen_urls:
                    content = ""
                    try:
                        content_elem = item.find_element(By.CSS_SELECTOR, ".RichContent-inner, .SearchItem-metaText")
                        content = content_elem.text.strip()
                    except NoSuchElementException:
                        pass

                    posts.append({
                        'id': post_id,
                        'url': url,
                        'title': title,
                        'content': content,
                        'type': post_type,
                        'crawl_time': datetime.now().isoformat()
                    })
                    seen_urls.add(url)
                    new_posts_added_this_scroll += 1
                    if len(posts) >= max_posts:
                        break
            except Exception:
                continue

        if new_posts_added_this_scroll == 0 and scroll_attempts > 0:
            print("本轮滚动未发现新帖子，可能已达页面底部或已爬取全部。")
            break

        if len(posts) < max_posts:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(random.uniform(2.5, 4.0))
            scroll_attempts += 1
        else:
            break

    return posts



def get_comments_for_answer(driver, answer_url, answer_id):
    print(f"    正在尝试获取评论: {answer_url}")
    driver.get(answer_url)
    time.sleep(2)  # 给页面一些初始加载时间
    human_behavior(driver)

    comments = []
    seen_comment_ids = set()  # 用于去重评论

    try:
        # 确保页面加载主要内容
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".AnswerCard, .QuestionAnswer-content, .ZVideo-content"))
        )
    except Exception:
        print("    页面未正常加载回答/文章区域。")
        return comments

    try:
        # 尝试点击“展开评论”按钮
        comment_button_selectors = [
            (By.XPATH, "//*[contains(@class,'Button') and contains(.,'评论')]"),  # 常见评论按钮文本
            (By.CSS_SELECTOR, ".Button.Comment-btn"),  # 常见评论按钮类名
            (By.CSS_SELECTOR, ".Comments-container .Button--withIcon"),  # 可能带图标的评论按钮
            (By.CSS_SELECTOR, ".QuestionAnswer-CommentBtn"),  # 问题回答页面的评论按钮
            (By.XPATH, "//button[contains(@class, 'Button') and contains(@class, 'Comments-button')]")  # 某些新版本知乎的评论按钮类
        ]

        clicked_comment_button = False
        for selector_type, selector_value in comment_button_selectors:
            try:
                comment_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((selector_type, selector_value))
                )
                driver.execute_script("arguments[0].click();", comment_button)
                time.sleep(2)  # 等待评论区模态框加载
                print("      成功点击评论按钮。")
                clicked_comment_button = True
                break
            except TimeoutException:
                continue  # 尝试下一个选择器
            except Exception as e:
                print(f"      点击评论按钮失败 ({selector_value}): {e}")
                continue

        if not clicked_comment_button:
            print("      未找到可点击的评论按钮或评论区已默认展开。")
            # 如果没有点击评论按钮，但评论区可能已经存在（例如，直接打开评论URL）
            # 我们仍然尝试等待评论容器出现

        try:
            comments_modal = WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".Modal-wrapper, .Modal-content"))
            )
            print("      评论模态框已出现。")
        except TimeoutException:
            print("      评论模态框未出现，可能页面结构变化。")
            return comments

        # 不再等待评论列表容器，直接查找所有评论项
        comment_elements = driver.find_elements(By.CSS_SELECTOR, "div.Modal-content div[data-id]")
        print(f"      实际处理 {len(comment_elements)} 条唯一评论元素。")

        # 尝试点击“查看更多评论”或“展开评论”
        # 增加循环次数，模拟多次点击加载更多
        for _ in range(10):  # 增加尝试次数，确保加载更多
            try:
                # 寻找“查看更多回复”或“加载更多评论”按钮
                load_more_button_selectors = [
                    (By.XPATH,
                     "//button[contains(.,'查看更多回复') or contains(.,'查看其他') and contains(.,'条回复') or contains(.,'加载更多评论') or contains(.,'展开更多')]"),
                    (By.CSS_SELECTOR, ".CommentListV2-footer .Button, .CommentsV2-footer .Button"),
                    (By.CSS_SELECTOR, ".Comments-container .Button--link"),
                    (By.CSS_SELECTOR, ".Button.Comment-MoreButton")  # 截图 image_2931b0.jpg 中显示的类
                ]

                load_more_btn_found = False
                for selector_type, selector_value in load_more_button_selectors:
                    try:
                        # 在整个 driver 范围内查找加载更多按钮，因为其可能不在 comments_container 内
                        load_more_btn = WebDriverWait(driver, 3).until(  # 短暂等待，如果找不到就尝试下一个
                            EC.element_to_be_clickable((selector_type, selector_value))
                        )
                        # 确保按钮在可视区域，并点击
                        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", load_more_btn)
                        driver.execute_script("arguments[0].click();", load_more_btn)
                        time.sleep(random.uniform(1.5, 3.0))  # 等待新评论加载
                        human_behavior(driver)  # 模拟行为
                        load_more_btn_found = True
                        print(f"      点击了加载更多评论按钮: {selector_value}")
                        break
                    except TimeoutException:
                        continue
                    except StaleElementReferenceException:
                        print("      StaleElementReferenceException while loading more comments, trying again.")
                        continue
                    except Exception as e:
                        # print(f"      点击加载更多评论按钮失败 ({selector_value}): {e}")
                        continue

                if not load_more_btn_found:
                    # 如果所有加载更多按钮都尝试过且没找到，就退出循环
                    print("      未找到加载更多评论按钮或已加载完全部评论。")
                    break

            except Exception as e:
                print(f"      加载更多评论流程中发生错误: {e}")
                break  # 退出循环

        # 直接全局查找所有模态框里的评论项
        comment_elements = driver.find_elements(By.CSS_SELECTOR, "div.Modal-wrapper div[data-id]")

        print(f"      实际处理 {len(comment_elements)} 条唯一评论元素。")

        for item in comment_elements:
            try:
                comment_id = item.get_attribute("data-id") or item.get_attribute(
                    "id") or f"no_id_{random.randint(1000, 9999)}"
                # 评论内容
                content = ""
                try:
                    content_elem = item.find_element(By.CSS_SELECTOR,
                                                     "div.CommentContent p, .RichText, .CommentItemV2-content")
                    content = content_elem.text.strip()
                except Exception:
                    pass
                # 评论作者
                author_name = ""
                try:
                    author_elem = item.find_element(By.CSS_SELECTOR,
                                                    "a.UserLink-link, span.UserLink-link, .CommentItem-author")
                    author_name = author_elem.text.strip()
                except Exception:
                    pass
                parent_id = item.get_attribute("data-parent-id")
                comments.append({
                    'id': comment_id,
                    'content': content,
                    'author': author_name,
                    'parent_id': parent_id,
                    'post_id': answer_id,
                    'crawl_time': datetime.now().isoformat()
                })
            except Exception as e:
                print(f"        抓取单条评论出错：{e}")
                continue
    except Exception as e:
        print(f"    获取评论过程中发生错误: {e}")

    return comments


def main():
    # 用户输入知乎用户slug或主页URL
    user_input = input("请输入知乎用户主页URL或slug（如 https://www.zhihu.com/people/xxx 或 xxx）: ").strip()
    if user_input.startswith("http"):
        user_slug = user_input.rstrip('/').split('/')[-1]
    else:
        user_slug = user_input

    all_posts_data = []
    all_comments_data = []

    driver = None
    try:
        driver = init_driver()
        load_cookies(driver)
        if not is_logged_in(driver):
            manual_login(driver)

        posts = get_user_posts(driver, user_slug, MAX_POSTS)
        print(f'\n--- 共获取到 {len(posts)} 个帖子 ---')

        for idx, post in enumerate(posts, 1):
            print(f'[{idx}/{len(posts)}] 类型: {post["type"]}, 标题: {post["title"]}')
            all_posts_data.append(post)
            # 只对answer类型的帖子抓评论
            if post['type'] == 'answer':
                comments = get_comments_for_answer(driver, post['url'], post['id'])
                print(f'  评论数: {len(comments)}')
                for comment in comments:
                    comment['post_id'] = post['id']
                    comment['crawl_time'] = datetime.now().isoformat()
                    all_comments_data.append(comment)
            time.sleep(random.uniform(1, 3))

        # 保存到Excel
        if all_posts_data:
            posts_df = pd.DataFrame(all_posts_data)
            with pd.ExcelWriter(EXCEL_PATH, engine='xlsxwriter') as writer:
                posts_df.to_excel(writer, sheet_name='Posts', index=False)
                if all_comments_data:
                    comments_df = pd.DataFrame(all_comments_data)
                    comments_df.to_excel(writer, sheet_name='Comments', index=False)
            print(f'\n所有数据已成功保存到 {EXCEL_PATH}')
        else:
            print("\n没有爬取到任何帖子，未生成Excel文件。")

    except Exception as e:
        print(f"主程序运行发生错误: {e}")
    finally:
        if driver:
            driver.quit()
        print("\n浏览器已关闭。")

if __name__ == '__main__':
    main()

#https://www.zhihu.com/people/nimingkeji