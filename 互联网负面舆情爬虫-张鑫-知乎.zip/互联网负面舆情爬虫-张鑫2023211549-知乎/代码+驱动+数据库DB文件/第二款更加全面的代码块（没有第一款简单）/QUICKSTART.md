# 知乎负面舆情爬虫系统 - 快速开始指南

## 🚀 快速开始

### 1. 环境准备

确保您的系统已安装：
- Python 3.7 或更高版本
- pip 包管理器

### 2. 安装系统

#### 方法一：自动安装（推荐）
```bash
# 运行安装脚本
python install.py
```

#### 方法二：手动安装
```bash
# 安装基础依赖
pip install requests beautifulsoup4 pandas numpy jieba textblob tqdm python-dotenv

# 安装可选依赖（用于高级功能）
pip install selenium fake-useragent lxml wordcloud matplotlib seaborn plotly scikit-learn
```

### 3. 快速测试

运行演示模式，测试系统功能：
```bash
python demo.py
```

或者：
```bash
python main.py
```

## 📖 基本使用

### 1. 爬取特定主题的帖子
```bash
python main.py --mode crawl --topic "人工智能" --max-posts 50
```

### 2. 爬取特定用户的帖子
```bash
python main.py --mode crawl --user "用户名" --max-posts 20
```

### 3. 分析已有数据
```bash
python main.py --mode analyze
```

### 4. 完整流程（爬取+分析）
```bash
python main.py --mode full --topic "科技" --max-posts 100 --max-comments 500
```

## 🎯 功能演示

### 情感分析演示
系统会自动分析以下类型的文本：
- 正面内容：`"这个产品真的很棒，我很喜欢！"`
- 负面内容：`"太糟糕了，完全不符合预期"`
- 涉政内容：`"政府应该加强监管，打击腐败行为"`
- 娱乐八卦：`"这个明星的绯闻真多，私生活混乱"`

### 负面关键词检测
系统内置了6个类别的负面关键词库：
1. **涉政有害** - 政治敏感词汇
2. **侮辱谩骂** - 人身攻击词汇
3. **色情暴力** - 不当内容词汇
4. **事故灾难** - 事故描述词汇
5. **聚集维权** - 群体事件词汇
6. **娱乐八卦** - 明星绯闻词汇

## 📊 输出结果

### 数据文件
- `data/zhihu_sentiment.db` - SQLite数据库文件
- `exports/` - CSV导出文件目录

### 分析报告
- `analysis_results/analysis_report.md` - 详细分析报告
- `analysis_results/*.png` - 可视化图表（如果安装了matplotlib）

### 控制台输出
- 爬取进度信息
- 分析统计结果
- 错误和警告信息

## ⚙️ 配置说明

编辑 `config.py` 文件可以调整：
- 爬虫延迟时间
- 数据库路径
- 负面关键词库
- 情感分析阈值

## 🔧 故障排除

### 常见问题

1. **模块导入错误**
   ```bash
   pip install -r requirements.txt
   ```

2. **数据库错误**
   - 确保 `data` 目录存在
   - 检查文件权限

3. **爬取失败**
   - 检查网络连接
   - 增加延迟时间
   - 更新User-Agent

### 获取帮助
```bash
python main.py --help
```

## 📝 使用示例

### 示例1：分析科技话题
```bash
# 爬取科技相关帖子
python main.py --mode crawl --topic "科技" --max-posts 50

# 分析数据
python main.py --mode analyze
```

### 示例2：分析特定用户
```bash
# 爬取用户帖子
python main.py --mode crawl --user "科技博主" --max-posts 20

# 完整分析
python main.py --mode full --user "科技博主"
```

### 示例3：批量处理
```bash
# 爬取多个主题
python main.py --mode crawl --topic "人工智能" --max-posts 30
python main.py --mode crawl --topic "机器学习" --max-posts 30
python main.py --mode crawl --topic "深度学习" --max-posts 30

# 统一分析
python main.py --mode analyze
```

## ⚠️ 注意事项

1. **法律合规**
   - 请遵守知乎的使用条款
   - 合理控制爬取频率
   - 仅用于学术研究和学习目的

2. **技术限制**
   - 知乎可能会更新反爬虫机制
   - 需要定期更新User-Agent
   - 建议在服务器环境下运行

3. **性能优化**
   - 大量数据爬取时建议分批进行
   - 可以调整延迟时间避免被封IP
   - 建议使用代理IP进行大规模爬取

## 🆘 技术支持

如果遇到问题，请：
1. 查看控制台错误信息
2. 检查依赖包是否正确安装
3. 确认配置文件设置
4. 运行演示模式测试基本功能

---

**祝您使用愉快！** 🎉 