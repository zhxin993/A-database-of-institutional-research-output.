#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
知乎负面舆情爬虫系统安装脚本
"""

import os
import sys
import subprocess
import platform

def check_python_version():
    """检查Python版本"""
    print("检查Python版本...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("错误: 需要Python 3.7或更高版本")
        print(f"当前版本: {version.major}.{version.minor}.{version.micro}")
        return False
    else:
        print(f"Python版本检查通过: {version.major}.{version.minor}.{version.micro}")
        return True

def install_package(package):
    """安装单个包"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError:
        return False

def install_requirements():
    """安装依赖包"""
    print("\n安装依赖包...")
    
    # 基础依赖包
    basic_packages = [
        "requests>=2.31.0",
        "beautifulsoup4>=4.12.2",
        "pandas>=2.1.3",
        "numpy>=1.25.2",
        "jieba>=0.42.1",
        "textblob>=0.17.1",
        "tqdm>=4.66.1",
        "python-dotenv>=1.0.0"
    ]
    
    # 可选依赖包（用于高级功能）
    optional_packages = [
        "selenium>=4.15.2",
        "fake-useragent>=1.4.0",
        "lxml>=4.9.3",
        "wordcloud>=1.9.2",
        "matplotlib>=3.8.2",
        "seaborn>=0.13.0",
        "plotly>=5.17.0",
        "scikit-learn>=1.3.2",
        "transformers>=4.35.2",
        "torch>=2.1.1",
        "flask>=3.0.0"
    ]
    
    print("安装基础依赖包...")
    for package in basic_packages:
        print(f"安装 {package}...")
        if install_package(package):
            print(f"✓ {package} 安装成功")
        else:
            print(f"✗ {package} 安装失败")
    
    print("\n安装可选依赖包...")
    for package in optional_packages:
        print(f"安装 {package}...")
        if install_package(package):
            print(f"✓ {package} 安装成功")
        else:
            print(f"⚠ {package} 安装失败（可选包）")

def create_directories():
    """创建必要的目录"""
    print("\n创建目录结构...")
    
    directories = [
        "./data",
        "./exports",
        "./analysis_results",
        "./models",
        "./logs"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✓ 创建目录: {directory}")

def create_config_file():
    """创建配置文件"""
    print("\n检查配置文件...")
    
    if not os.path.exists("config.py"):
        print("配置文件不存在，请确保config.py文件存在")
        return False
    else:
        print("✓ 配置文件存在")
        return True

def test_imports():
    """测试关键模块导入"""
    print("\n测试模块导入...")
    
    test_modules = [
        ("requests", "网络请求"),
        ("bs4", "HTML解析"),
        ("pandas", "数据处理"),
        ("jieba", "中文分词"),
        ("textblob", "情感分析")
    ]
    
    failed_modules = []
    
    for module, description in test_modules:
        try:
            __import__(module)
            print(f"✓ {module} ({description}) 导入成功")
        except ImportError as e:
            print(f"✗ {module} ({description}) 导入失败: {e}")
            failed_modules.append(module)
    
    if failed_modules:
        print(f"\n警告: 以下模块导入失败: {', '.join(failed_modules)}")
        print("请手动安装这些模块或检查安装过程")
        return False
    else:
        print("\n✓ 所有关键模块导入成功")
        return True

def test_system():
    """测试系统功能"""
    print("\n测试系统功能...")
    
    try:
        # 测试数据库
        from database import DatabaseManager
        db = DatabaseManager()
        print("✓ 数据库模块测试成功")
        
        # 测试情感分析
        from sentiment_analyzer import SentimentAnalyzer
        analyzer = SentimentAnalyzer()
        result = analyzer.analyze_text("测试文本")
        print("✓ 情感分析模块测试成功")
        
        # 测试爬虫
        from simple_crawler import SimpleZhihuCrawler
        crawler = SimpleZhihuCrawler()
        print("✓ 爬虫模块测试成功")
        
        return True
        
    except Exception as e:
        print(f"✗ 系统功能测试失败: {e}")
        return False

def show_usage():
    """显示使用说明"""
    print("\n" + "="*60)
    print("安装完成！")
    print("="*60)
    
    print("\n使用方法:")
    print("1. 演示模式:")
    print("   python demo.py")
    print("   python main.py")
    
    print("\n2. 爬取数据:")
    print("   python main.py --mode crawl --topic \"人工智能\"")
    print("   python main.py --mode crawl --user \"用户名\"")
    
    print("\n3. 分析数据:")
    print("   python main.py --mode analyze")
    
    print("\n4. 完整流程:")
    print("   python main.py --mode full --topic \"科技\"")
    
    print("\n5. 查看帮助:")
    print("   python main.py --help")
    
    print("\n注意事项:")
    print("- 首次使用建议先运行演示模式")
    print("- 爬取数据时请遵守网站使用条款")
    print("- 大量数据爬取时建议分批进行")
    print("- 如遇到问题，请检查依赖包是否正确安装")

def main():
    """主安装函数"""
    print("知乎负面舆情爬虫系统 - 安装脚本")
    print("="*50)
    
    # 检查Python版本
    if not check_python_version():
        return
    
    # 安装依赖包
    install_requirements()
    
    # 创建目录
    create_directories()
    
    # 检查配置文件
    if not create_config_file():
        print("请确保config.py文件存在")
        return
    
    # 测试导入
    if not test_imports():
        print("部分模块导入失败，请检查安装")
    
    # 测试系统功能
    if test_system():
        print("\n✓ 系统安装和测试完成")
        show_usage()
    else:
        print("\n✗ 系统测试失败，请检查安装")

if __name__ == "__main__":
    main() 