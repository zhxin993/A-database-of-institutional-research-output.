#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
知乎负面舆情爬虫系统演示脚本
"""

import os
import sys
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import DatabaseManager
from sentiment_analyzer import SentimentAnalyzer
from simple_analyzer import SimpleAnalyzer

def demo_sentiment_analysis():
    """演示情感分析功能"""
    print("=" * 50)
    print("1. 情感分析功能演示")
    print("=" * 50)
    
    analyzer = SentimentAnalyzer()
    
    # 测试文本
    test_cases = [
        {
            "text": "这个产品真的很棒，我很喜欢！",
            "expected": "正面"
        },
        {
            "text": "太糟糕了，完全不符合预期，浪费钱",
            "expected": "负面"
        },
        {
            "text": "政府应该加强监管，打击腐败行为",
            "expected": "涉政有害"
        },
        {
            "text": "这个明星的绯闻真多，私生活混乱",
            "expected": "娱乐八卦"
        },
        {
            "text": "今天天气不错，心情很好",
            "expected": "中性"
        }
    ]
    
    for i, case in enumerate(test_cases, 1):
        print(f"\n测试案例 {i}:")
        print(f"文本: {case['text']}")
        print(f"预期: {case['expected']}")
        
        result = analyzer.analyze_text(case['text'])
        
        print(f"分析结果:")
        print(f"  是否负面: {result['is_negative']}")
        print(f"  负面类别: {result['negative_category']}")
        print(f"  情感分数: {result['sentiment_score']:.3f}")
        print(f"  置信度: {result['confidence']:.3f}")
        
        if result['keyword_matches']:
            print(f"  关键词匹配: {result['keyword_matches']}")

def demo_keyword_statistics():
    """演示关键词统计功能"""
    print("\n" + "=" * 50)
    print("2. 负面关键词统计演示")
    print("=" * 50)
    
    analyzer = SentimentAnalyzer()
    summary = analyzer.get_negative_keywords_summary()
    
    print("负面关键词库统计:")
    for category, info in summary.items():
        print(f"\n{category}:")
        print(f"  关键词数量: {info['keyword_count']}")
        print(f"  示例关键词: {', '.join(info['keywords'])}")

def demo_database_operations():
    """演示数据库操作功能"""
    print("\n" + "=" * 50)
    print("3. 数据库操作演示")
    print("=" * 50)
    
    # 初始化数据库
    db = DatabaseManager()
    
    # 插入测试数据
    test_post = {
        'zhihu_id': 'test_001',
        'title': '测试帖子标题',
        'content': '这是一个测试帖子的内容，包含一些负面词汇如腐败、贪污等',
        'author': '测试用户',
        'author_url': 'https://www.zhihu.com/people/test',
        'publish_time': datetime.now().isoformat(),
        'update_time': datetime.now().isoformat(),
        'view_count': 100,
        'like_count': 10,
        'comment_count': 5,
        'share_count': 2,
        'topic': '测试主题'
    }
    
    test_comment = {
        'zhihu_id': 'comment_001',
        'post_id': 'test_001',
        'parent_id': None,
        'content': '这个评论包含一些侮辱性词汇',
        'author': '评论用户',
        'author_url': 'https://www.zhihu.com/people/commenter',
        'publish_time': datetime.now().isoformat(),
        'like_count': 3,
        'reply_count': 1
    }
    
    # 插入数据
    print("插入测试帖子...")
    success = db.insert_post(test_post)
    print(f"帖子插入: {'成功' if success else '失败'}")
    
    print("插入测试评论...")
    success = db.insert_comment(test_comment)
    print(f"评论插入: {'成功' if success else '失败'}")
    
    # 查询数据
    print("\n查询测试数据...")
    posts = db.get_posts_by_topic('测试主题')
    print(f"找到 {len(posts)} 个帖子")
    
    comments = db.get_comments_by_post('test_001')
    print(f"找到 {len(comments)} 条评论")
    
    # 获取统计信息
    stats = db.get_statistics()
    print(f"\n数据库统计:")
    print(f"  总帖子数: {stats.get('total_posts', 0)}")
    print(f"  总评论数: {stats.get('total_comments', 0)}")

def demo_sentiment_analysis_on_data():
    """演示对数据库中的数据进行情感分析"""
    print("\n" + "=" * 50)
    print("4. 数据情感分析演示")
    print("=" * 50)
    
    db = DatabaseManager()
    analyzer = SentimentAnalyzer()
    
    # 获取所有帖子
    posts = db.get_posts_by_topic('')
    comments = db.get_comments_by_post('')
    
    print(f"分析 {len(posts)} 个帖子和 {len(comments)} 条评论...")
    
    # 分析帖子
    for post in posts:
        content = f"{post.get('title', '')} {post.get('content', '')}"
        result = analyzer.analyze_text(content)
        
        # 更新数据库
        db.update_post_sentiment(
            post['zhihu_id'],
            result['is_negative'],
            result['negative_category'],
            result['sentiment_score']
        )
    
    # 分析评论
    for comment in comments:
        content = comment.get('content', '')
        result = analyzer.analyze_text(content)
        
        # 更新数据库
        db.update_comment_sentiment(
            comment['zhihu_id'],
            result['is_negative'],
            result['negative_category'],
            result['sentiment_score']
        )
    
    # 获取负面内容
    negative_posts = db.get_negative_posts()
    negative_comments = db.get_negative_comments()
    
    print(f"\n分析结果:")
    print(f"  负面帖子数: {len(negative_posts)}")
    print(f"  负面评论数: {len(negative_comments)}")
    
    if negative_posts:
        print("\n负面帖子示例:")
        for post in negative_posts[:3]:  # 显示前3个
            print(f"  - {post.get('title', '无标题')} (类别: {post.get('negative_category', '未知')})")
    
    if negative_comments:
        print("\n负面评论示例:")
        for comment in negative_comments[:3]:  # 显示前3个
            content = comment.get('content', '')[:50] + "..." if len(comment.get('content', '')) > 50 else comment.get('content', '')
            print(f"  - {content} (类别: {comment.get('negative_category', '未知')})")

def demo_data_analysis():
    """演示数据分析功能"""
    print("\n" + "=" * 50)
    print("5. 数据分析演示")
    print("=" * 50)
    
    db = DatabaseManager()
    analyzer = SentimentAnalyzer()
    data_analyzer = SimpleAnalyzer(db, analyzer)
    
    # 生成基础统计
    print("生成基础统计信息...")
    stats = data_analyzer.generate_basic_statistics()
    
    # 分析负面类别
    print("\n分析负面内容类别...")
    category_stats = data_analyzer.analyze_negative_categories()
    
    # 生成分析报告
    print("\n生成分析报告...")
    try:
        report = data_analyzer.generate_analysis_report()
        print("分析报告生成成功！")
    except Exception as e:
        print(f"生成报告时出错: {e}")

def main():
    """主演示函数"""
    print("知乎负面舆情爬虫系统 - 功能演示")
    print("=" * 60)
    print(f"演示开始时间: {datetime.now()}")
    
    try:
        # 1. 情感分析演示
        demo_sentiment_analysis()
        
        # 2. 关键词统计演示
        demo_keyword_statistics()
        
        # 3. 数据库操作演示
        demo_database_operations()
        
        # 4. 数据情感分析演示
        demo_sentiment_analysis_on_data()
        
        # 5. 数据分析演示
        demo_data_analysis()
        
        print("\n" + "=" * 60)
        print("演示完成！")
        print(f"演示结束时间: {datetime.now()}")
        
        print("\n使用说明:")
        print("1. 运行 'python main.py --mode crawl --topic \"主题\"' 开始爬取数据")
        print("2. 运行 'python main.py --mode analyze' 进行数据分析")
        print("3. 运行 'python main.py --mode full --topic \"主题\"' 完整流程")
        
    except Exception as e:
        print(f"\n演示过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 