# 知乎负面舆情爬虫系统

## 项目简介

这是一个基于Python的知乎负面舆情爬虫系统，能够自动爬取知乎帖子、评论，并进行负面舆情检测和分析。

## 功能特性

### 1. 数据爬取
- **主题搜索**: 根据特定主题爬取前100个帖子
- **用户爬取**: 爬取指定用户的所有帖子
- **评论获取**: 爬取帖子对应的所有评论和回复，保留回复关系
- **数据存储**: 将爬取数据以合理结构存入SQLite数据库

### 2. 负面舆情检测
- **关键词检测**: 基于6个主题的关键词表进行负面内容识别
  - 涉政有害
  - 侮辱谩骂
  - 色情暴力
  - 事故灾难
  - 聚集维权
  - 娱乐八卦
- **情感分析**: 使用TextBlob进行情感倾向分析
- **智能算法**: 结合关键词匹配和情感分析的综合判断

### 3. 数据分析与可视化
- **统计分析**: 生成详细的负面内容统计报告
- **可视化图表**: 创建类别分布、情感分布、词云等图表
- **交互式仪表板**: 提供Web交互式分析界面
- **数据导出**: 支持CSV格式数据导出

## 系统架构

```
├── config.py              # 配置文件
├── database.py            # 数据库管理模块
├── zhihu_crawler.py       # 知乎爬虫模块
├── sentiment_analyzer.py  # 情感分析模块
├── data_analyzer.py       # 数据分析模块
├── main.py               # 主程序入口
├── requirements.txt      # 依赖包列表
└── README.md            # 项目说明
```

## 安装与配置

### 1. 环境要求
- Python 3.7+
- Chrome浏览器（使用Selenium时）

### 2. 安装依赖
```bash
pip install -r requirements.txt
```

### 3. 配置设置
编辑 `config.py` 文件，根据需要调整配置参数：
- 爬虫延迟时间
- 数据库路径
- 负面关键词库
- 情感分析阈值

## 使用方法

### 1. 基本使用

#### 爬取特定主题的帖子
```bash
python main.py --mode crawl --topic "人工智能" --max-posts 100
```

#### 爬取特定用户的帖子
```bash
python main.py --mode crawl --user "用户名" --max-posts 50
```

#### 完整流程（爬取+分析）
```bash
python main.py --mode full --topic "科技" --max-posts 100 --max-comments 1000
```

#### 仅进行数据分析
```bash
python main.py --mode analyze
```

### 2. 演示模式
```bash
python main.py
```

### 3. 高级选项
```bash
# 使用Selenium进行爬取
python main.py --mode crawl --topic "政治" --use-selenium

# 自定义爬取数量
python main.py --mode full --topic "教育" --max-posts 200 --max-comments 500
```

## 负面关键词库

系统内置了6个类别的负面关键词库，每个类别包含50+个关键词：

### 1. 涉政有害
- 政治敏感词汇
- 政府相关负面词汇
- 社会秩序相关词汇

### 2. 侮辱谩骂
- 人身攻击词汇
- 侮辱性语言
- 恶意评价词汇

### 3. 色情暴力
- 色情内容相关词汇
- 暴力行为描述
- 不当内容词汇

### 4. 事故灾难
- 事故描述词汇
- 灾难相关词汇
- 伤亡事件词汇

### 5. 聚集维权
- 群体事件词汇
- 维权活动词汇
- 抗议示威词汇

### 6. 娱乐八卦
- 明星绯闻词汇
- 娱乐负面词汇
- 八卦内容词汇

## 数据库结构

### posts表（帖子表）
- zhihu_id: 知乎帖子ID
- title: 帖子标题
- content: 帖子内容
- author: 作者
- publish_time: 发布时间
- is_negative: 是否负面
- negative_category: 负面类别
- sentiment_score: 情感分数

### comments表（评论表）
- zhihu_id: 评论ID
- post_id: 所属帖子ID
- parent_id: 父评论ID
- content: 评论内容
- author: 评论作者
- is_negative: 是否负面
- negative_category: 负面类别
- sentiment_score: 情感分数

## 输出结果

### 1. 数据文件
- `data/zhihu_sentiment.db`: SQLite数据库文件
- `exports/`: CSV导出文件目录

### 2. 分析报告
- `analysis_results/analysis_report.md`: 分析报告
- `analysis_results/dashboard.html`: 交互式仪表板
- `analysis_results/*.png`: 可视化图表

### 3. 控制台输出
- 爬取进度信息
- 分析统计结果
- 错误和警告信息

## 注意事项

### 1. 法律合规
- 请遵守知乎的使用条款
- 合理控制爬取频率，避免对服务器造成压力
- 仅用于学术研究和学习目的

### 2. 技术限制
- 知乎可能会更新反爬虫机制
- 需要定期更新User-Agent和请求头
- Selenium模式需要Chrome浏览器

### 3. 性能优化
- 大量数据爬取时建议分批进行
- 可以调整延迟时间避免被封IP
- 建议在服务器环境下运行

## 扩展功能

### 1. 模型训练
系统支持自定义情感分析模型训练：
```python
from sentiment_analyzer import SentimentAnalyzer

analyzer = SentimentAnalyzer()
analyzer.train_model(texts, labels, model_path='./models/sentiment_model.pkl')
```

### 2. 关键词扩展
可以在config.py中添加新的负面关键词：
```python
NEGATIVE_KEYWORDS['新类别'] = ['关键词1', '关键词2', ...]
```

### 3. 数据源扩展
可以扩展支持其他平台的数据爬取，只需实现相应的爬虫模块。

## 故障排除

### 1. 爬取失败
- 检查网络连接
- 更新User-Agent
- 增加延迟时间
- 使用Selenium模式

### 2. 数据库错误
- 检查数据库文件权限
- 确保data目录存在
- 检查SQLite版本兼容性

### 3. 依赖包问题
- 更新pip: `pip install --upgrade pip`
- 重新安装依赖: `pip install -r requirements.txt --force-reinstall`

## 贡献指南

欢迎提交Issue和Pull Request来改进这个项目。

## 许可证

本项目仅供学习和研究使用，请勿用于商业用途。

## 联系方式

如有问题或建议，请通过GitHub Issues联系。 