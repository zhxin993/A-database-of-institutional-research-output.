import pandas as pd
import os
from typing import Dict, List
from database import DatabaseManager
from sentiment_analyzer import SentimentAnalyzer

class SimpleAnalyzer:
    def __init__(self, db_manager: DatabaseManager, sentiment_analyzer: SentimentAnalyzer):
        """初始化简化分析器"""
        self.db = db_manager
        self.sentiment_analyzer = sentiment_analyzer
        
        # 创建输出目录
        self.output_dir = './analysis_results'
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_basic_statistics(self) -> Dict:
        """生成基础统计信息"""
        stats = self.db.get_statistics()
        
        print("=== 基础统计信息 ===")
        print(f"总帖子数: {stats.get('total_posts', 0)}")
        print(f"总评论数: {stats.get('total_comments', 0)}")
        print(f"负面帖子数: {stats.get('negative_posts', 0)}")
        print(f"负面评论数: {stats.get('negative_comments', 0)}")
        
        if stats.get('total_posts', 0) > 0:
            negative_post_ratio = stats.get('negative_posts', 0) / stats.get('total_posts', 0) * 100
            print(f"负面帖子比例: {negative_post_ratio:.2f}%")
        
        if stats.get('total_comments', 0) > 0:
            negative_comment_ratio = stats.get('negative_comments', 0) / stats.get('total_comments', 0) * 100
            print(f"负面评论比例: {negative_comment_ratio:.2f}%")
        
        return stats
    
    def analyze_negative_categories(self) -> Dict:
        """分析负面内容类别分布"""
        negative_posts = self.db.get_negative_posts()
        negative_comments = self.db.get_negative_comments()
        
        # 统计各类别数量
        category_stats = {}
        
        for post in negative_posts:
            category = post.get('negative_category', '未知')
            category_stats[category] = category_stats.get(category, 0) + 1
        
        for comment in negative_comments:
            category = comment.get('negative_category', '未知')
            category_stats[category] = category_stats.get(category, 0) + 1
        
        print("\n=== 负面内容类别分布 ===")
        for category, count in sorted(category_stats.items(), key=lambda x: x[1], reverse=True):
            print(f"{category}: {count}")
        
        return category_stats
    
    def generate_analysis_report(self) -> str:
        """生成分析报告"""
        report = []
        report.append("# 知乎负面舆情分析报告\n")
        
        # 基础统计
        stats = self.generate_basic_statistics()
        report.append("## 1. 基础统计信息\n")
        report.append(f"- 总帖子数: {stats.get('total_posts', 0)}")
        report.append(f"- 总评论数: {stats.get('total_comments', 0)}")
        report.append(f"- 负面帖子数: {stats.get('negative_posts', 0)}")
        report.append(f"- 负面评论数: {stats.get('negative_comments', 0)}")
        
        if stats.get('total_posts', 0) > 0:
            negative_post_ratio = stats.get('negative_posts', 0) / stats.get('total_posts', 0) * 100
            report.append(f"- 负面帖子比例: {negative_post_ratio:.2f}%")
        
        if stats.get('total_comments', 0) > 0:
            negative_comment_ratio = stats.get('negative_comments', 0) / stats.get('total_comments', 0) * 100
            report.append(f"- 负面评论比例: {negative_comment_ratio:.2f}%\n")
        
        # 类别分析
        category_stats = self.analyze_negative_categories()
        report.append("## 2. 负面内容类别分析\n")
        for category, count in sorted(category_stats.items(), key=lambda x: x[1], reverse=True):
            report.append(f"- {category}: {count}")
        report.append("")
        
        # 关键词分析
        report.append("## 3. 负面关键词统计\n")
        keywords_summary = self.sentiment_analyzer.get_negative_keywords_summary()
        for category, info in keywords_summary.items():
            report.append(f"### {category}")
            report.append(f"- 关键词数量: {info['keyword_count']}")
            report.append(f"- 示例关键词: {', '.join(info['keywords'])}\n")
        
        # 建议和结论
        report.append("## 4. 分析结论与建议\n")
        report.append("### 主要发现:")
        report.append("1. 负面内容主要集中在某些特定类别")
        report.append("2. 需要重点关注高频负面关键词")
        report.append("3. 建议加强内容审核和用户教育")
        report.append("\n### 改进建议:")
        report.append("1. 建立更完善的负面内容检测机制")
        report.append("2. 加强用户行为分析和预警")
        report.append("3. 定期更新负面关键词库")
        
        # 保存报告
        report_text = '\n'.join(report)
        with open(os.path.join(self.output_dir, 'analysis_report.md'), 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(f"分析报告已保存到: {os.path.join(self.output_dir, 'analysis_report.md')}")
        return report_text 