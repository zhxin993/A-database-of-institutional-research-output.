import jieba
import re
from typing import Dict, List, Tuple, Optional
from textblob import TextBlob
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import pickle
import os

from config import NEGATIVE_KEYWORDS, SENTIMENT_CONFIG

class SentimentAnalyzer:
    def __init__(self):
        """初始化情感分析器"""
        self.negative_keywords = NEGATIVE_KEYWORDS
        self.sentiment_config = SENTIMENT_CONFIG
        self.model = None
        self.vectorizer = None
        
        # 初始化jieba分词
        jieba.initialize()
        
        # 加载自定义词典
        self._load_custom_dict()
    
    def _load_custom_dict(self):
        """加载自定义词典"""
        # 添加负面词汇到jieba词典
        for category, keywords in self.negative_keywords.items():
            for keyword in keywords:
                jieba.add_word(keyword)
    
    def analyze_text(self, text: str) -> Dict:
        """分析文本的情感倾向和负面类别"""
        if not text or len(text.strip()) == 0:
            return {
                'is_negative': False,
                'negative_category': None,
                'sentiment_score': 0.0,
                'confidence': 0.0
            }
        
        # 分词
        words = list(jieba.cut(text))
        
        # 关键词检测
        keyword_result = self._detect_keywords(text, words)
        
        # 情感分析
        sentiment_result = self._analyze_sentiment(text)
        
        # 综合判断
        is_negative = keyword_result['is_negative'] or sentiment_result['is_negative']
        negative_category = keyword_result['category'] if keyword_result['is_negative'] else sentiment_result['category']
        sentiment_score = sentiment_result['score']
        confidence = max(keyword_result['confidence'], sentiment_result['confidence'])
        
        return {
            'is_negative': is_negative,
            'negative_category': negative_category,
            'sentiment_score': sentiment_score,
            'confidence': confidence,
            'keyword_matches': keyword_result['matches'],
            'sentiment_details': sentiment_result
        }
    
    def _detect_keywords(self, text: str, words: List[str]) -> Dict:
        """基于关键词检测负面内容"""
        matches = {}
        max_category = None
        max_count = 0
        
        for category, keywords in self.negative_keywords.items():
            count = 0
            matched_keywords = []
            
            for keyword in keywords:
                if keyword in text:
                    count += 1
                    matched_keywords.append(keyword)
            
            if count > 0:
                matches[category] = {
                    'count': count,
                    'keywords': matched_keywords
                }
                
                if count > max_count:
                    max_count = count
                    max_category = category
        
        # 判断是否为负面内容
        is_negative = max_count >= 1  # 至少包含一个负面关键词
        confidence = min(max_count / 5.0, 1.0)  # 关键词越多，置信度越高
        
        return {
            'is_negative': is_negative,
            'category': max_category,
            'confidence': confidence,
            'matches': matches
        }
    
    def _analyze_sentiment(self, text: str) -> Dict:
        """情感分析"""
        try:
            # 使用TextBlob进行情感分析
            blob = TextBlob(text)
            sentiment_score = blob.sentiment.polarity
            
            # 判断情感倾向
            if sentiment_score < self.sentiment_config['negative_threshold']:
                is_negative = True
                category = '情感负面'
            elif sentiment_score > self.sentiment_config['positive_threshold']:
                is_negative = False
                category = '情感正面'
            else:
                is_negative = False
                category = '情感中性'
            
            # 计算置信度
            confidence = abs(sentiment_score)
            
            return {
                'is_negative': is_negative,
                'category': category,
                'score': sentiment_score,
                'confidence': confidence
            }
        except Exception as e:
            print(f"情感分析失败: {e}")
            return {
                'is_negative': False,
                'category': '分析失败',
                'score': 0.0,
                'confidence': 0.0
            }
    
    def analyze_batch(self, texts: List[str]) -> List[Dict]:
        """批量分析文本"""
        results = []
        for text in texts:
            result = self.analyze_text(text)
            results.append(result)
        return results
    
    def get_negative_statistics(self, texts: List[str]) -> Dict:
        """获取负面内容统计"""
        results = self.analyze_batch(texts)
        
        # 统计各类别数量
        category_counts = {}
        total_negative = 0
        
        for result in results:
            if result['is_negative']:
                total_negative += 1
                category = result['negative_category']
                if category:
                    category_counts[category] = category_counts.get(category, 0) + 1
        
        return {
            'total_texts': len(texts),
            'negative_count': total_negative,
            'negative_ratio': total_negative / len(texts) if texts else 0,
            'category_distribution': category_counts
        }
    
    def train_model(self, texts: List[str], labels: List[int], model_path: str = None):
        """训练情感分析模型"""
        try:
            # 创建管道
            self.model = Pipeline([
                ('tfidf', TfidfVectorizer(max_features=5000, stop_words='english')),
                ('classifier', MultinomialNB())
            ])
            
            # 训练模型
            self.model.fit(texts, labels)
            
            # 保存模型
            if model_path:
                os.makedirs(os.path.dirname(model_path), exist_ok=True)
                with open(model_path, 'wb') as f:
                    pickle.dump(self.model, f)
                print(f"模型已保存到: {model_path}")
                
        except Exception as e:
            print(f"训练模型失败: {e}")
    
    def load_model(self, model_path: str):
        """加载预训练模型"""
        try:
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            print(f"模型已从 {model_path} 加载")
        except Exception as e:
            print(f"加载模型失败: {e}")
    
    def predict_with_model(self, text: str) -> Dict:
        """使用训练好的模型进行预测"""
        if self.model is None:
            return self.analyze_text(text)
        
        try:
            # 使用模型预测
            prediction = self.model.predict([text])[0]
            probability = self.model.predict_proba([text])[0]
            
            is_negative = bool(prediction)
            confidence = max(probability)
            
            return {
                'is_negative': is_negative,
                'negative_category': '模型预测',
                'sentiment_score': probability[1] - probability[0],  # 正负概率差
                'confidence': confidence,
                'prediction': prediction,
                'probabilities': probability.tolist()
            }
        except Exception as e:
            print(f"模型预测失败: {e}")
            return self.analyze_text(text)
    
    def extract_keywords(self, text: str, top_k: int = 10) -> List[Tuple[str, float]]:
        """提取文本关键词"""
        try:
            words = list(jieba.cut(text))
            
            # 过滤停用词和短词
            filtered_words = [word for word in words if len(word) > 1 and not word.isspace()]
            
            # 计算词频
            word_freq = {}
            for word in filtered_words:
                word_freq[word] = word_freq.get(word, 0) + 1
            
            # 排序并返回top_k
            sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            return sorted_words[:top_k]
            
        except Exception as e:
            print(f"关键词提取失败: {e}")
            return []
    
    def get_negative_keywords_summary(self) -> Dict:
        """获取负面关键词统计摘要"""
        summary = {}
        for category, keywords in self.negative_keywords.items():
            summary[category] = {
                'keyword_count': len(keywords),
                'keywords': keywords[:10]  # 只显示前10个关键词
            }
        return summary 