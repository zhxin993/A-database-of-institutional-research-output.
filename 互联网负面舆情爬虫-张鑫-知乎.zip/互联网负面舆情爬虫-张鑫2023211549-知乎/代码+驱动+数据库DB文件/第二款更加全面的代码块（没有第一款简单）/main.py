#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import sys
import os
from datetime import datetime
import time
import pickle
import random
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import sqlite3

from database import DatabaseManager
from simple_crawler import SimpleZhihuCrawler
from sentiment_analyzer import SentimentAnalyzer
from simple_analyzer import SimpleAnalyzer

# 配置
CHROME_DRIVER_PATH = 'chromedriver.exe'  # 或你的chromedriver实际路径
USER_DATA_DIR = r"D:\chrome_user_data"     # 用于记住登录
COOKIES_PATH = './zhihu_cookies.pkl'
TOPIC = '校园霸凌'
MAX_POSTS = 100
DB_PATH = 'zhihu_data.db'

def get_comments(driver, post_url):
    driver.get(post_url)
    time.sleep(2)
    human_behavior(driver)
    comments = []
    try:
        while True:
            items = driver.find_elements(By.CSS_SELECTOR, ".CommentItem, .CommentItemV2")
            for item in items:
                try:
                    comment_id = item.get_attribute("data-comment-id") or item.get_attribute("id")
                    content = item.find_element(By.CSS_SELECTOR, ".CommentItemV2-content, .CommentItem-content").text
                    parent_id = item.get_attribute("data-parent-id")
                    comments.append({'id': comment_id, 'content': content, 'parent_id': parent_id})
                except Exception:
                    continue
            # 加载更多
            try:
                load_more = driver.find_element(By.CSS_SELECTOR, ".CommentListV2-footer .Button")
                if load_more.is_displayed():
                    load_more.click()
                    time.sleep(2)
                    continue
            except Exception:
                pass
            break
    except Exception:
        pass
    return comments

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id TEXT PRIMARY KEY,
            url TEXT,
            title TEXT,
            content TEXT,
            crawl_time TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id TEXT PRIMARY KEY,
            post_id TEXT,
            parent_id TEXT,
            content TEXT,
            crawl_time TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_post(post):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        INSERT OR IGNORE INTO posts (id, url, title, content, crawl_time)
        VALUES (?, ?, ?, ?, ?)
    ''', (post['id'], post['url'], post['title'], post['content'], datetime.now().isoformat()))
    conn.commit()
    conn.close()

def insert_comment(comment, post_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        INSERT OR IGNORE INTO comments (id, post_id, parent_id, content, crawl_time)
        VALUES (?, ?, ?, ?, ?)
    ''', (comment['id'], post_id, comment['parent_id'], comment['content'], datetime.now().isoformat()))
    conn.commit()
    conn.close()

def init_driver():
    chrome_options = Options()
    chrome_options.add_argument(f'--user-data-dir={USER_DATA_DIR}')
    chrome_options.add_argument('--window-size=1200,900')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(service=Service(CHROME_DRIVER_PATH), options=chrome_options)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    return driver

def save_cookies(driver):
    with open(COOKIES_PATH, 'wb') as f:
        pickle.dump(driver.get_cookies(), f)

def load_cookies(driver):
    if os.path.exists(COOKIES_PATH):
        driver.get('https://www.zhihu.com')
        with open(COOKIES_PATH, 'rb') as f:
            cookies = pickle.load(f)
        for cookie in cookies:
            try:
                driver.add_cookie(cookie)
            except Exception:
                pass
        driver.refresh()
        time.sleep(2)

def is_logged_in(driver):
    try:
        driver.find_element(By.CSS_SELECTOR, ".AppHeader-profileEntry, .TopNavBar-avatar")
        return True
    except:
        return False

def manual_login(driver):
    print('请在弹出的浏览器中手动登录知乎，登录后按回车继续...')
    driver.get('https://www.zhihu.com')
    input()
    save_cookies(driver)

def human_behavior(driver):
    actions = ActionChains(driver)
    body = driver.find_element(By.TAG_NAME, "body")
    actions.move_to_element(body).perform()
    time.sleep(random.uniform(0.1, 0.3))
    driver.execute_script(f"window.scrollBy(0, {random.randint(100, 500)});")
    time.sleep(random.uniform(0.5, 1.5))

def switch_to_tab(driver, tab_name):
    try:
        tab = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, f"//div[contains(@class,'SearchTabs')]//button[contains(.,'{tab_name}')]"))
        )
        tab.click()
        time.sleep(2)
        return True
    except Exception as e:
        print(f"未找到{tab_name}Tab，页面结构可能变动：", e)
        return False

def search_topic(driver, topic):
    from urllib.parse import quote
    search_url = f"https://www.zhihu.com/search?q={quote(topic)}&type=content"
    driver.get(search_url)
    time.sleep(3)

def get_posts(driver, max_posts):
    posts = []
    seen = set()
    last_count = 0
    scroll_times = 0
    while len(posts) < max_posts and scroll_times < 50:
        items = driver.find_elements(By.CSS_SELECTOR, ".ContentItem, .css-1n8i4of, .css-1v4g5g7, div[data-za-detail-view-path], .List-item")
        for item in items:
            try:
                links = item.find_elements(By.CSS_SELECTOR, "a[href*='/question/']")
                if not links:
                    continue
                url = links[0].get_attribute("href")
                post_id = re.search(r'/question/(\d+)', url)
                if not post_id or url in seen:
                    continue
                seen.add(url)
                try:
                    title = item.find_element(By.CSS_SELECTOR, "h2, .ContentItem-title").text
                except:
                    title = ""
                try:
                    content = item.find_element(By.CSS_SELECTOR, ".RichContent-inner, .css-1v4g5g7").text
                except:
                    content = ""
                posts.append({'id': post_id.group(1), 'url': url, 'title': title, 'content': content})
                if len(posts) >= max_posts:
                    break
            except Exception:
                continue
        if len(posts) == last_count:
            break
        last_count = len(posts)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(random.uniform(2, 3))
        scroll_times += 1
    return posts

def main():
    """主程序入口"""
    parser = argparse.ArgumentParser(description='知乎负面舆情爬虫系统')
    parser.add_argument('--mode', choices=['crawl', 'analyze', 'full'], 
                       default='full', help='运行模式')
    parser.add_argument('--topic', type=str, help='搜索主题')
    parser.add_argument('--user', type=str, help='用户名')
    parser.add_argument('--max-posts', type=int, default=100, help='最大帖子数量')
    parser.add_argument('--max-comments', type=int, default=1000, help='最大评论数量')
    parser.add_argument('--use-selenium', action='store_true', help='使用Selenium')
    
    args = parser.parse_args()
    
    print("=== 知乎负面舆情爬虫系统 ===")
    print(f"运行模式: {args.mode}")
    print(f"开始时间: {datetime.now()}")
    
    # 初始化组件
    db = DatabaseManager()
    crawler = SimpleZhihuCrawler()
    sentiment_analyzer = SentimentAnalyzer()
    data_analyzer = SimpleAnalyzer(db, sentiment_analyzer)
    
    try:
        if args.mode in ['crawl', 'full']:
            # 爬取数据
            if args.topic:
                print(f"\n开始爬取主题: {args.topic}")
                posts = crawler.search_posts_by_topic(args.topic, args.max_posts)
                
                # 爬取评论
                for post in posts:
                    post_id = post.get('zhihu_id')
                    if post_id:
                        comments = crawler.get_post_comments(post_id, args.max_comments)
                        print(f"帖子 {post_id} 获取到 {len(comments)} 条评论")
            
            elif args.user:
                print(f"\n开始爬取用户: {args.user}")
                posts = crawler.get_user_posts(args.user)
                
                # 爬取评论
                for post in posts:
                    post_id = post.get('zhihu_id')
                    if post_id:
                        comments = crawler.get_post_comments(post_id, args.max_comments)
                        print(f"帖子 {post_id} 获取到 {len(comments)} 条评论")
            else:
                print("请指定 --topic 或 --user 参数")
                return
        
        if args.mode in ['analyze', 'full']:
            # 分析数据
            print("\n开始分析数据...")
            
            # 获取所有帖子和评论进行情感分析
            posts = db.get_posts_by_topic('')  # 获取所有帖子
            comments = db.get_comments_by_post('')  # 获取所有评论
            
            print(f"分析 {len(posts)} 个帖子和 {len(comments)} 条评论")
            
            # 分析帖子
            for post in posts:
                content = f"{post.get('title', '')} {post.get('content', '')}"
                result = sentiment_analyzer.analyze_text(content)
                
                db.update_post_sentiment(
                    post['zhihu_id'],
                    result['is_negative'],
                    result['negative_category'],
                    result['sentiment_score']
                )
            
            # 分析评论
            for comment in comments:
                content = comment.get('content', '')
                result = sentiment_analyzer.analyze_text(content)
                
                db.update_comment_sentiment(
                    comment['zhihu_id'],
                    result['is_negative'],
                    result['negative_category'],
                    result['sentiment_score']
                )
            
            # 生成分析报告
            print("\n生成分析报告...")
            data_analyzer.generate_basic_statistics()
            category_stats = data_analyzer.analyze_negative_categories()
            
            # 生成报告
            report = data_analyzer.generate_analysis_report()
            print("\n分析完成！")
        
        # 导出数据
        print("\n导出数据...")
        db.export_to_csv()
        
    except KeyboardInterrupt:
        print("\n用户中断程序")
    except Exception as e:
        print(f"\n程序运行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        crawler.close()
        print(f"\n程序结束时间: {datetime.now()}")

def demo_mode():
    """演示模式"""
    print("=== 演示模式 ===")
    
    # 初始化组件
    db = DatabaseManager()
    sentiment_analyzer = SentimentAnalyzer()
    data_analyzer = SimpleAnalyzer(db, sentiment_analyzer)
    
    # 演示情感分析
    print("\n1. 情感分析演示")
    test_texts = [
        "这个产品真的很棒，我很喜欢！",
        "太糟糕了，完全不符合预期",
        "政府应该加强监管",
        "这个明星的绯闻真多",
        "今天天气不错"
    ]
    
    for text in test_texts:
        result = sentiment_analyzer.analyze_text(text)
        print(f"文本: {text}")
        print(f"结果: {result}")
        print()
    
    # 演示关键词统计
    print("\n2. 负面关键词统计")
    keywords_summary = sentiment_analyzer.get_negative_keywords_summary()
    for category, info in keywords_summary.items():
        print(f"{category}: {info['keyword_count']} 个关键词")
    
    # 演示数据库操作
    print("\n3. 数据库操作演示")
    stats = db.get_statistics()
    print(f"数据库统计: {stats}")

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # 如果没有参数，运行演示模式
        demo_mode()
    else:
        main() 