import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from wordcloud import WordCloud
import jieba
from collections import Counter
from typing import Dict, List, Optional
import os

from database import DatabaseManager
from sentiment_analyzer import SentimentAnalyzer

class DataAnalyzer:
    def __init__(self, db_manager: DatabaseManager, sentiment_analyzer: SentimentAnalyzer):
        """初始化数据分析器"""
        self.db = db_manager
        self.sentiment_analyzer = sentiment_analyzer
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
        
        # 创建输出目录
        self.output_dir = './analysis_results'
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_basic_statistics(self) -> Dict:
        """生成基础统计信息"""
        stats = self.db.get_statistics()
        
        print("=== 基础统计信息 ===")
        print(f"总帖子数: {stats.get('total_posts', 0)}")
        print(f"总评论数: {stats.get('total_comments', 0)}")
        print(f"负面帖子数: {stats.get('negative_posts', 0)}")
        print(f"负面评论数: {stats.get('negative_comments', 0)}")
        
        if stats.get('total_posts', 0) > 0:
            negative_post_ratio = stats.get('negative_posts', 0) / stats.get('total_posts', 0) * 100
            print(f"负面帖子比例: {negative_post_ratio:.2f}%")
        
        if stats.get('total_comments', 0) > 0:
            negative_comment_ratio = stats.get('negative_comments', 0) / stats.get('total_comments', 0) * 100
            print(f"负面评论比例: {negative_comment_ratio:.2f}%")
        
        return stats
    
    def analyze_negative_categories(self) -> Dict:
        """分析负面内容类别分布"""
        negative_posts = self.db.get_negative_posts()
        negative_comments = self.db.get_negative_comments()
        
        # 统计各类别数量
        category_stats = {}
        
        for post in negative_posts:
            category = post.get('negative_category', '未知')
            category_stats[category] = category_stats.get(category, 0) + 1
        
        for comment in negative_comments:
            category = comment.get('negative_category', '未知')
            category_stats[category] = category_stats.get(category, 0) + 1
        
        print("\n=== 负面内容类别分布 ===")
        for category, count in sorted(category_stats.items(), key=lambda x: x[1], reverse=True):
            print(f"{category}: {count}")
        
        return category_stats
    
    def create_category_chart(self, category_stats: Dict):
        """创建类别分布图表"""
        categories = list(category_stats.keys())
        counts = list(category_stats.values())
        
        # 创建柱状图
        plt.figure(figsize=(12, 6))
        bars = plt.bar(categories, counts, color='skyblue', alpha=0.7)
        
        # 添加数值标签
        for bar, count in zip(bars, counts):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, 
                    str(count), ha='center', va='bottom')
        
        plt.title('负面内容类别分布', fontsize=16, fontweight='bold')
        plt.xlabel('类别', fontsize=12)
        plt.ylabel('数量', fontsize=12)
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        # 保存图表
        plt.savefig(os.path.join(self.output_dir, 'negative_categories.png'), dpi=300, bbox_inches='tight')
        plt.show()
    
    def create_sentiment_distribution(self):
        """创建情感分布图表"""
        # 获取所有帖子和评论的情感分数
        with self.db.db_path as conn:
            posts_df = pd.read_sql_query('SELECT sentiment_score FROM posts', conn)
            comments_df = pd.read_sql_query('SELECT sentiment_score FROM comments', conn)
        
        # 创建子图
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 帖子情感分布
        ax1.hist(posts_df['sentiment_score'].dropna(), bins=30, alpha=0.7, color='blue', edgecolor='black')
        ax1.set_title('帖子情感分数分布', fontsize=14, fontweight='bold')
        ax1.set_xlabel('情感分数', fontsize=12)
        ax1.set_ylabel('频次', fontsize=12)
        ax1.grid(True, alpha=0.3)
        
        # 评论情感分布
        ax2.hist(comments_df['sentiment_score'].dropna(), bins=30, alpha=0.7, color='red', edgecolor='black')
        ax2.set_title('评论情感分数分布', fontsize=14, fontweight='bold')
        ax2.set_xlabel('情感分数', fontsize=12)
        ax2.set_ylabel('频次', fontsize=12)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'sentiment_distribution.png'), dpi=300, bbox_inches='tight')
        plt.show()
    
    def create_wordcloud(self, text_type: str = 'all'):
        """创建词云图"""
        texts = []
        
        if text_type in ['all', 'posts']:
            posts = self.db.get_negative_posts()
            for post in posts:
                content = post.get('content', '') + ' ' + post.get('title', '')
                texts.append(content)
        
        if text_type in ['all', 'comments']:
            comments = self.db.get_negative_comments()
            for comment in comments:
                content = comment.get('content', '')
                texts.append(content)
        
        # 合并所有文本
        all_text = ' '.join(texts)
        
        # 分词
        words = jieba.cut(all_text)
        word_freq = Counter(words)
        
        # 过滤停用词和短词
        filtered_words = {word: freq for word, freq in word_freq.items() 
                         if len(word) > 1 and not word.isspace() and freq > 1}
        
        # 创建词云
        wordcloud = WordCloud(
            font_path='simhei.ttf',  # 需要中文字体文件
            width=800,
            height=400,
            background_color='white',
            max_words=100,
            colormap='viridis'
        ).generate_from_frequencies(filtered_words)
        
        plt.figure(figsize=(12, 8))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title(f'负面内容词云图 ({text_type})', fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        plt.savefig(os.path.join(self.output_dir, f'wordcloud_{text_type}.png'), dpi=300, bbox_inches='tight')
        plt.show()
    
    def analyze_temporal_trends(self):
        """分析时间趋势"""
        # 获取时间序列数据
        with self.db.db_path as conn:
            posts_df = pd.read_sql_query('''
                SELECT DATE(publish_time) as date, COUNT(*) as count,
                       SUM(CASE WHEN is_negative = 1 THEN 1 ELSE 0 END) as negative_count
                FROM posts 
                WHERE publish_time IS NOT NULL
                GROUP BY DATE(publish_time)
                ORDER BY date
            ''', conn)
            
            comments_df = pd.read_sql_query('''
                SELECT DATE(publish_time) as date, COUNT(*) as count,
                       SUM(CASE WHEN is_negative = 1 THEN 1 ELSE 0 END) as negative_count
                FROM comments 
                WHERE publish_time IS NOT NULL
                GROUP BY DATE(publish_time)
                ORDER BY date
            ''', conn)
        
        # 创建时间趋势图
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10))
        
        # 帖子时间趋势
        ax1.plot(posts_df['date'], posts_df['count'], label='总帖子数', color='blue', alpha=0.7)
        ax1.plot(posts_df['date'], posts_df['negative_count'], label='负面帖子数', color='red', alpha=0.7)
        ax1.set_title('帖子发布趋势', fontsize=14, fontweight='bold')
        ax1.set_xlabel('日期', fontsize=12)
        ax1.set_ylabel('数量', fontsize=12)
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 评论时间趋势
        ax2.plot(comments_df['date'], comments_df['count'], label='总评论数', color='green', alpha=0.7)
        ax2.plot(comments_df['date'], comments_df['negative_count'], label='负面评论数', color='orange', alpha=0.7)
        ax2.set_title('评论发布趋势', fontsize=14, fontweight='bold')
        ax2.set_xlabel('日期', fontsize=12)
        ax2.set_ylabel('数量', fontsize=12)
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'temporal_trends.png'), dpi=300, bbox_inches='tight')
        plt.show()
    
    def create_interactive_dashboard(self):
        """创建交互式仪表板"""
        # 获取统计数据
        stats = self.db.get_statistics()
        category_stats = self.analyze_negative_categories()
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('总体统计', '负面类别分布', '情感分布', '时间趋势'),
            specs=[[{"type": "indicator"}, {"type": "bar"}],
                   [{"type": "histogram"}, {"type": "scatter"}]]
        )
        
        # 总体统计指标
        fig.add_trace(
            go.Indicator(
                mode="gauge+number+delta",
                value=stats.get('negative_posts', 0),
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "负面帖子数"},
                delta={'reference': stats.get('total_posts', 0)},
                gauge={'axis': {'range': [None, stats.get('total_posts', 0)]},
            ),
            row=1, col=1
        )
        
        # 负面类别分布
        categories = list(category_stats.keys())
        counts = list(category_stats.values())
        
        fig.add_trace(
            go.Bar(x=categories, y=counts, name="负面类别"),
            row=1, col=2
        )
        
        # 情感分布
        with self.db.db_path as conn:
            posts_df = pd.read_sql_query('SELECT sentiment_score FROM posts WHERE sentiment_score IS NOT NULL', conn)
        
        fig.add_trace(
            go.Histogram(x=posts_df['sentiment_score'], nbinsx=30, name="情感分布"),
            row=2, col=1
        )
        
        # 时间趋势
        with self.db.db_path as conn:
            time_df = pd.read_sql_query('''
                SELECT DATE(publish_time) as date, COUNT(*) as count
                FROM posts 
                WHERE publish_time IS NOT NULL
                GROUP BY DATE(publish_time)
                ORDER BY date
            ''', conn)
        
        fig.add_trace(
            go.Scatter(x=time_df['date'], y=time_df['count'], mode='lines+markers', name="帖子数量"),
            row=2, col=2
        )
        
        fig.update_layout(height=800, title_text="知乎负面舆情分析仪表板")
        fig.write_html(os.path.join(self.output_dir, 'dashboard.html'))
        
        print(f"交互式仪表板已保存到: {os.path.join(self.output_dir, 'dashboard.html')}")
    
    def generate_analysis_report(self) -> str:
        """生成分析报告"""
        report = []
        report.append("# 知乎负面舆情分析报告\n")
        
        # 基础统计
        stats = self.generate_basic_statistics()
        report.append("## 1. 基础统计信息\n")
        report.append(f"- 总帖子数: {stats.get('total_posts', 0)}")
        report.append(f"- 总评论数: {stats.get('total_comments', 0)}")
        report.append(f"- 负面帖子数: {stats.get('negative_posts', 0)}")
        report.append(f"- 负面评论数: {stats.get('negative_comments', 0)}")
        
        if stats.get('total_posts', 0) > 0:
            negative_post_ratio = stats.get('negative_posts', 0) / stats.get('total_posts', 0) * 100
            report.append(f"- 负面帖子比例: {negative_post_ratio:.2f}%")
        
        if stats.get('total_comments', 0) > 0:
            negative_comment_ratio = stats.get('negative_comments', 0) / stats.get('total_comments', 0) * 100
            report.append(f"- 负面评论比例: {negative_comment_ratio:.2f}%\n")
        
        # 类别分析
        category_stats = self.analyze_negative_categories()
        report.append("## 2. 负面内容类别分析\n")
        for category, count in sorted(category_stats.items(), key=lambda x: x[1], reverse=True):
            report.append(f"- {category}: {count}")
        report.append("")
        
        # 关键词分析
        report.append("## 3. 负面关键词统计\n")
        keywords_summary = self.sentiment_analyzer.get_negative_keywords_summary()
        for category, info in keywords_summary.items():
            report.append(f"### {category}")
            report.append(f"- 关键词数量: {info['keyword_count']}")
            report.append(f"- 示例关键词: {', '.join(info['keywords'])}\n")
        
        # 建议和结论
        report.append("## 4. 分析结论与建议\n")
        report.append("### 主要发现:")
        report.append("1. 负面内容主要集中在某些特定类别")
        report.append("2. 需要重点关注高频负面关键词")
        report.append("3. 建议加强内容审核和用户教育")
        report.append("\n### 改进建议:")
        report.append("1. 建立更完善的负面内容检测机制")
        report.append("2. 加强用户行为分析和预警")
        report.append("3. 定期更新负面关键词库")
        
        # 保存报告
        report_text = '\n'.join(report)
        with open(os.path.join(self.output_dir, 'analysis_report.md'), 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(f"分析报告已保存到: {os.path.join(self.output_dir, 'analysis_report.md')}")
        return report_text 