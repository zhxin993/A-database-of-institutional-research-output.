#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import json
import os
import pickle
import random
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.chrome.service import Service
import requests
from bs4 import BeautifulSoup
import re

from database import DatabaseManager
from config import CRAWLER_CONFIG, ZHIHU_CONFIG

class ZhihuAppCrawler:
    def __init__(self, chrome_driver_path: str = None, user_data_dir: str = None):
        """初始化知乎APP爬虫"""
        self.db = DatabaseManager()
        self.driver = None
        self.wait = None
        self.is_logged_in = False
        
        # 登录状态文件
        self.login_state_file = './data/login_state.pkl'
        self.cookies_file = './data/zhihu_cookies.pkl'
        
        # 确保数据目录存在
        os.makedirs('./data', exist_ok=True)
        
        # 初始化Chrome驱动
        self.init_chrome_driver(chrome_driver_path, user_data_dir)
    
    def init_chrome_driver(self, chrome_driver_path: str = None, user_data_dir: str = None):
        """初始化Chrome驱动"""
        try:
            chrome_options = Options()
            
            # 基本设置
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--disable-blink-features=AutomationControlled')
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # 设置用户数据目录（用于保持登录状态）
            if user_data_dir:
                chrome_options.add_argument(f'--user-data-dir={user_data_dir}')
            else:
                chrome_options.add_argument('--user-data-dir=./data/chrome_user_data')
            
            # 设置窗口大小
            chrome_options.add_argument('--window-size=1920,1080')
            
            # 设置User-Agent
            chrome_options.add_argument(f'--user-agent={CRAWLER_CONFIG["user_agent"]}')
            
            # 禁用图片加载以提高速度
            prefs = {
                "profile.managed_default_content_settings.images": 2,
                "profile.default_content_setting_values.notifications": 2
            }
            chrome_options.add_experimental_option("prefs", prefs)
            
            # 创建驱动
            if chrome_driver_path:
                service = Service(chrome_driver_path)
                self.driver = webdriver.Chrome(service=service, options=chrome_options)
            else:
                self.driver = webdriver.Chrome(options=chrome_options)
            
            # 执行反检测脚本
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            
            # 设置等待对象
            self.wait = WebDriverWait(self.driver, 20)
            
            print("Chrome驱动初始化成功")
            
        except Exception as e:
            print(f"Chrome驱动初始化失败: {e}")
            raise
    
    def save_cookies(self):
        """保存cookies"""
        try:
            cookies = self.driver.get_cookies()
            with open(self.cookies_file, 'wb') as f:
                pickle.dump(cookies, f)
            print("Cookies已保存")
        except Exception as e:
            print(f"保存cookies失败: {e}")
    
    def load_cookies(self):
        """加载cookies"""
        try:
            if os.path.exists(self.cookies_file):
                with open(self.cookies_file, 'rb') as f:
                    cookies = pickle.load(f)
                
                # 先访问知乎首页
                self.driver.get("https://www.zhihu.com")
                time.sleep(2)
                
                # 添加cookies
                for cookie in cookies:
                    try:
                        self.driver.add_cookie(cookie)
                    except Exception as e:
                        print(f"添加cookie失败: {e}")
                
                # 刷新页面
                self.driver.refresh()
                time.sleep(3)
                
                # 检查是否已登录
                if self.check_login_status():
                    self.is_logged_in = True
                    print("使用已保存的登录状态")
                    return True
                else:
                    print("保存的登录状态已失效")
                    return False
            return False
        except Exception as e:
            print(f"加载cookies失败: {e}")
            return False
    
    def check_login_status(self) -> bool:
        """检查登录状态"""
        try:
            # 检查是否存在登录相关元素
            login_elements = self.driver.find_elements(By.CSS_SELECTOR, ".SignContainer")
            if login_elements:
                return False
            
            # 检查是否存在用户头像等登录后元素
            user_elements = self.driver.find_elements(By.CSS_SELECTOR, ".AppHeader-profileEntry")
            if user_elements:
                return True
            
            return False
        except Exception as e:
            print(f"检查登录状态失败: {e}")
            return False
    
    def manual_login(self):
        """手动登录"""
        print("请手动登录知乎...")
        print("登录完成后，程序将自动继续...")
        
        # 访问知乎首页
        self.driver.get("https://www.zhihu.com")
        
        # 等待用户手动登录
        while not self.check_login_status():
            time.sleep(2)
            print("等待登录...")
        
        # 登录成功后保存状态
        self.is_logged_in = True
        self.save_cookies()
        print("登录成功！")
    
    def ensure_login(self):
        """确保已登录"""
        if not self.is_logged_in:
            # 尝试加载已保存的登录状态
            if not self.load_cookies():
                # 如果加载失败，进行手动登录
                self.manual_login()
    
    def random_delay(self, min_delay: float = 1.0, max_delay: float = 3.0):
        """随机延迟"""
        delay = random.uniform(min_delay, max_delay)
        time.sleep(delay)
    
    def simulate_human_behavior(self):
        """模拟人类行为"""
        # 随机鼠标移动
        actions = ActionChains(self.driver)
        
        # 获取页面尺寸
        page_width = self.driver.execute_script("return window.innerWidth;")
        page_height = self.driver.execute_script("return window.innerHeight;")
        
        # 随机移动鼠标
        for _ in range(random.randint(2, 5)):
            x = random.randint(100, page_width - 100)
            y = random.randint(100, page_height - 100)
            actions.move_by_offset(x, y)
            actions.perform()
            time.sleep(random.uniform(0.1, 0.3))
        
        # 随机滚动
        scroll_amount = random.randint(100, 500)
        self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
        time.sleep(random.uniform(0.5, 1.5))
    
    def search_topic(self, topic: str, max_posts: int = 100) -> List[Dict]:
        """搜索特定主题的帖子"""
        print(f"开始搜索主题: {topic}")
        
        # 确保已登录
        self.ensure_login()
        
        # 访问知乎首页
        self.driver.get("https://www.zhihu.com")
        self.random_delay(2, 4)
        
        # 模拟人类行为
        self.simulate_human_behavior()
        
        # 查找搜索框并输入主题
        try:
            # 等待搜索框出现
            search_box = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder*='搜索'], input[placeholder*='Search']"))
            )
            
            # 点击搜索框
            search_box.click()
            self.random_delay(0.5, 1.0)
            
            # 清空搜索框
            search_box.clear()
            self.random_delay(0.5, 1.0)
            
            # 输入搜索关键词
            for char in topic:
                search_box.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            self.random_delay(1, 2)
            
            # 按回车搜索
            search_box.send_keys(Keys.RETURN)
            self.random_delay(3, 5)
            
            # 切换到内容标签页
            try:
                content_tab = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, "//div[contains(text(), '内容') or contains(text(), 'Content')]"))
                )
                content_tab.click()
                self.random_delay(2, 4)
            except:
                print("未找到内容标签页，继续使用默认搜索结果")
            
            # 爬取帖子
            posts = self.extract_posts_from_search(topic, max_posts)
            
            return posts
            
        except Exception as e:
            print(f"搜索主题失败: {e}")
            return []
    
    def extract_posts_from_search(self, topic: str, max_posts: int) -> List[Dict]:
        """从搜索结果中提取帖子"""
        posts = []
        page = 1
        
        while len(posts) < max_posts:
            print(f"正在爬取第 {page} 页，已获取 {len(posts)} 个帖子")
            
            # 等待页面加载
            self.random_delay(2, 4)
            
            # 模拟人类行为
            self.simulate_human_behavior()
            
            # 查找帖子元素
            try:
                post_elements = self.driver.find_elements(By.CSS_SELECTOR, ".Search-result .ContentItem")
                
                if not post_elements:
                    print("未找到更多帖子")
                    break
                
                for element in post_elements:
                    if len(posts) >= max_posts:
                        break
                    
                    try:
                        post_data = self.extract_post_data(element, topic)
                        if post_data and post_data not in posts:
                            posts.append(post_data)
                            # 保存到数据库
                            self.db.insert_post(post_data)
                            print(f"已获取帖子: {post_data.get('title', '无标题')[:30]}...")
                    except Exception as e:
                        print(f"提取帖子数据失败: {e}")
                        continue
                
                # 滚动到页面底部加载更多内容
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                self.random_delay(3, 5)
                
                # 检查是否有更多内容
                new_elements = self.driver.find_elements(By.CSS_SELECTOR, ".Search-result .ContentItem")
                if len(new_elements) <= len(post_elements):
                    print("没有更多内容了")
                    break
                
                page += 1
                
            except Exception as e:
                print(f"提取帖子失败: {e}")
                break
        
        print(f"总共获取到 {len(posts)} 个帖子")
        return posts
    
    def extract_post_data(self, element, topic: str) -> Optional[Dict]:
        """提取帖子数据"""
        try:
            # 提取帖子链接
            link_element = element.find_element(By.CSS_SELECTOR, "a[href*='/question/']")
            post_url = link_element.get_attribute("href")
            
            # 提取帖子ID
            post_id_match = re.search(r'/question/(\d+)', post_url)
            if not post_id_match:
                return None
            post_id = post_id_match.group(1)
            
            # 提取标题
            title_element = element.find_element(By.CSS_SELECTOR, "h2, .ContentItem-title")
            title = title_element.text.strip() if title_element else ""
            
            # 提取内容
            content_element = element.find_element(By.CSS_SELECTOR, ".RichContent-inner, .ContentItem-content")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            try:
                author_element = element.find_element(By.CSS_SELECTOR, ".UserLink, .ContentItem-meta .UserLink")
                author = author_element.text.strip() if author_element else ""
                author_url = author_element.get_attribute("href") if author_element else ""
            except:
                author = ""
                author_url = ""
            
            # 提取统计信息
            stats = self.extract_post_stats(element)
            
            post_data = {
                'zhihu_id': post_id,
                'title': title,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'update_time': datetime.now().isoformat(),
                'view_count': stats.get('view_count', 0),
                'like_count': stats.get('like_count', 0),
                'comment_count': stats.get('comment_count', 0),
                'share_count': stats.get('share_count', 0),
                'topic': topic,
                'url': post_url
            }
            
            return post_data
            
        except Exception as e:
            print(f"提取帖子数据失败: {e}")
            return None
    
    def extract_post_stats(self, element) -> Dict:
        """提取帖子统计信息"""
        stats = {}
        try:
            # 提取浏览量
            view_elements = element.find_elements(By.CSS_SELECTOR, ".ContentItem-status")
            if view_elements:
                view_text = view_elements[0].text.strip()
                view_match = re.search(r'(\d+)', view_text)
                if view_match:
                    stats['view_count'] = int(view_match.group(1))
            
            # 提取点赞数
            like_elements = element.find_elements(By.CSS_SELECTOR, ".VoteButton")
            if like_elements:
                like_text = like_elements[0].text.strip()
                like_match = re.search(r'(\d+)', like_text)
                if like_match:
                    stats['like_count'] = int(like_match.group(1))
            
            # 提取评论数
            comment_elements = element.find_elements(By.CSS_SELECTOR, ".ContentItem-actions .Button")
            if comment_elements:
                comment_text = comment_elements[0].text.strip()
                comment_match = re.search(r'(\d+)', comment_text)
                if comment_match:
                    stats['comment_count'] = int(comment_match.group(1))
            
        except Exception as e:
            print(f"提取统计信息失败: {e}")
        
        return stats
    
    def get_post_comments(self, post_id: str, post_url: str, max_comments: int = 1000) -> List[Dict]:
        """获取帖子的所有评论和回复"""
        print(f"开始获取帖子 {post_id} 的评论")
        
        # 确保已登录
        self.ensure_login()
        
        # 访问帖子页面
        self.driver.get(post_url)
        self.random_delay(3, 5)
        
        # 模拟人类行为
        self.simulate_human_behavior()
        
        comments = []
        
        try:
            # 等待评论区域加载
            self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".CommentItem, .CommentItemV2"))
            )
            
            # 滚动加载更多评论
            self.load_more_comments()
            
            # 提取评论
            comment_elements = self.driver.find_elements(By.CSS_SELECTOR, ".CommentItem, .CommentItemV2")
            
            for element in comment_elements:
                if len(comments) >= max_comments:
                    break
                
                try:
                    comment_data = self.extract_comment_data(element, post_id)
                    if comment_data:
                        comments.append(comment_data)
                        # 保存到数据库
                        self.db.insert_comment(comment_data)
                except Exception as e:
                    print(f"提取评论数据失败: {e}")
                    continue
            
            print(f"成功获取帖子 {post_id} 的 {len(comments)} 条评论")
            
        except Exception as e:
            print(f"获取评论失败: {e}")
        
        return comments
    
    def load_more_comments(self):
        """加载更多评论"""
        try:
            # 滚动到评论区域
            comment_section = self.driver.find_element(By.CSS_SELECTOR, ".CommentList, .CommentItemV2-list")
            self.driver.execute_script("arguments[0].scrollIntoView();", comment_section)
            self.random_delay(2, 3)
            
            # 多次滚动加载更多评论
            for i in range(10):  # 最多滚动10次
                # 滚动到页面底部
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                self.random_delay(2, 4)
                
                # 模拟人类行为
                self.simulate_human_behavior()
                
                # 检查是否有"加载更多"按钮
                try:
                    load_more_btn = self.driver.find_element(By.CSS_SELECTOR, ".CommentListV2-footer .Button")
                    if load_more_btn.is_displayed():
                        load_more_btn.click()
                        self.random_delay(2, 4)
                except:
                    pass
                
                # 检查是否有新评论加载
                current_comments = len(self.driver.find_elements(By.CSS_SELECTOR, ".CommentItem, .CommentItemV2"))
                if i > 0 and current_comments <= self.last_comment_count:
                    break
                self.last_comment_count = current_comments
                
        except Exception as e:
            print(f"加载更多评论失败: {e}")
    
    def extract_comment_data(self, element, post_id: str) -> Optional[Dict]:
        """提取评论数据"""
        try:
            # 提取评论ID
            comment_id = element.get_attribute("data-comment-id") or element.get_attribute("id")
            if not comment_id:
                return None
            
            # 提取评论内容
            content_element = element.find_element(By.CSS_SELECTOR, ".CommentItemV2-content, .CommentItem-content")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            try:
                author_element = element.find_element(By.CSS_SELECTOR, ".CommentItemV2-meta .UserLink, .CommentItem-meta .UserLink")
                author = author_element.text.strip() if author_element else ""
                author_url = author_element.get_attribute("href") if author_element else ""
            except:
                author = ""
                author_url = ""
            
            # 提取父评论ID（回复关系）
            parent_id = element.get_attribute("data-parent-id")
            
            # 提取统计信息
            try:
                like_element = element.find_element(By.CSS_SELECTOR, ".VoteButton")
                like_count = int(like_element.text.strip()) if like_element else 0
            except:
                like_count = 0
            
            comment_data = {
                'zhihu_id': comment_id,
                'post_id': post_id,
                'parent_id': parent_id,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'like_count': like_count,
                'reply_count': 0
            }
            
            return comment_data
            
        except Exception as e:
            print(f"提取评论数据失败: {e}")
            return None
    
    def crawl_topic_with_comments(self, topic: str, max_posts: int = 100, max_comments_per_post: int = 1000):
        """爬取主题帖子及其评论"""
        print(f"开始爬取主题 '{topic}' 的帖子和评论")
        
        # 爬取帖子
        posts = self.search_topic(topic, max_posts)
        
        if not posts:
            print("未获取到任何帖子")
            return
        
        # 爬取每个帖子的评论
        for i, post in enumerate(posts, 1):
            post_id = post.get('zhihu_id')
            post_url = post.get('url')
            
            if post_id and post_url:
                print(f"\n[{i}/{len(posts)}] 爬取帖子 {post_id} 的评论...")
                comments = self.get_post_comments(post_id, post_url, max_comments_per_post)
                
                # 随机延迟，避免被封
                self.random_delay(5, 10)
        
        print(f"\n爬取完成！总共获取 {len(posts)} 个帖子")
    
    def close(self):
        """关闭爬虫"""
        if self.driver:
            self.driver.quit()
        print("爬虫已关闭")

def main():
    """主函数"""
    # 创建爬虫实例
    crawler = ZhihuAppCrawler()
    
    try:
        # 爬取"校园霸凌"主题
        topic = "校园霸凌"
        max_posts = 100
        max_comments_per_post = 1000
        
        crawler.crawl_topic_with_comments(topic, max_posts, max_comments_per_post)
        
    except KeyboardInterrupt:
        print("\n用户中断程序")
    except Exception as e:
        print(f"程序运行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        crawler.close()

if __name__ == "__main__":
    main() 