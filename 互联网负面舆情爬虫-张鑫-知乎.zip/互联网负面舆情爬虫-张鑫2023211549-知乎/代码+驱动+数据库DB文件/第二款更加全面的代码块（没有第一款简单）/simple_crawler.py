import requests
import time
import json
import re
from datetime import datetime
from typing import Dict, List, Optional
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

from config import CRAWLER_CONFIG, ZHIHU_CONFIG, DATA_CONFIG
from database import DatabaseManager

class SimpleZhihuCrawler:
    def __init__(self):
        """初始化简化知乎爬虫"""
        self.db = DatabaseManager()
        self.ua = UserAgent()
        self.session = requests.Session()
        
        # 设置请求头
        self.session.headers.update({
            'User-Agent': CRAWLER_CONFIG['user_agent'],
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
    
    def search_posts_by_topic(self, topic: str, max_posts: int = 100) -> List[Dict]:
        """根据主题搜索帖子（模拟数据）"""
        print(f"开始搜索主题: {topic}")
        
        # 生成模拟数据
        posts = []
        for i in range(min(max_posts, 10)):  # 限制为10个帖子用于演示
            post_data = {
                'zhihu_id': f'topic_{topic}_{i}',
                'title': f'关于{topic}的帖子标题{i+1}',
                'content': f'这是关于{topic}的帖子内容{i+1}，包含一些测试内容。',
                'author': f'用户{i+1}',
                'author_url': f'https://www.zhihu.com/people/user{i+1}',
                'publish_time': datetime.now().isoformat(),
                'update_time': datetime.now().isoformat(),
                'view_count': 100 + i * 10,
                'like_count': 10 + i,
                'comment_count': 5 + i,
                'share_count': 2 + i,
                'topic': topic
            }
            posts.append(post_data)
            
            # 保存到数据库
            self.db.insert_post(post_data)
            
            # 模拟延迟
            time.sleep(0.1)
        
        print(f"成功获取 {len(posts)} 个帖子")
        return posts
    
    def get_user_posts(self, username: str) -> List[Dict]:
        """获取用户的所有帖子（模拟数据）"""
        print(f"开始获取用户 {username} 的帖子")
        
        # 生成模拟数据
        posts = []
        for i in range(5):  # 生成5个帖子用于演示
            post_data = {
                'zhihu_id': f'user_{username}_{i}',
                'title': f'用户{username}的帖子标题{i+1}',
                'content': f'这是用户{username}发布的帖子内容{i+1}，包含一些测试内容。',
                'author': username,
                'author_url': f'https://www.zhihu.com/people/{username}',
                'publish_time': datetime.now().isoformat(),
                'update_time': datetime.now().isoformat(),
                'view_count': 200 + i * 20,
                'like_count': 20 + i * 2,
                'comment_count': 10 + i,
                'share_count': 5 + i,
                'topic': f'用户{username}的主题'
            }
            posts.append(post_data)
            
            # 保存到数据库
            self.db.insert_post(post_data)
            
            # 模拟延迟
            time.sleep(0.1)
        
        print(f"成功获取用户 {username} 的 {len(posts)} 个帖子")
        return posts
    
    def get_post_comments(self, post_id: str, max_comments: int = 1000) -> List[Dict]:
        """获取帖子的评论和回复（模拟数据）"""
        print(f"开始获取帖子 {post_id} 的评论")
        
        # 生成模拟评论数据
        comments = []
        comment_count = min(max_comments, 20)  # 限制为20条评论用于演示
        
        for i in range(comment_count):
            # 模拟一些负面评论
            if i % 3 == 0:  # 每3条评论中有1条负面
                content = f'这个帖子内容有问题，包含一些负面词汇如腐败、贪污等。评论{i+1}'
            else:
                content = f'这是第{i+1}条评论，内容正常。'
            
            comment_data = {
                'zhihu_id': f'comment_{post_id}_{i}',
                'post_id': post_id,
                'parent_id': None if i < 10 else f'comment_{post_id}_{i-10}',  # 模拟回复关系
                'content': content,
                'author': f'评论用户{i+1}',
                'author_url': f'https://www.zhihu.com/people/commenter{i+1}',
                'publish_time': datetime.now().isoformat(),
                'like_count': 1 + i % 5,
                'reply_count': 0
            }
            comments.append(comment_data)
            
            # 保存到数据库
            self.db.insert_comment(comment_data)
            
            # 模拟延迟
            time.sleep(0.05)
        
        print(f"成功获取帖子 {post_id} 的 {len(comments)} 条评论")
        return comments
    
    def close(self):
        """关闭爬虫"""
        self.session.close() 