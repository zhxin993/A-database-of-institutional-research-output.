import sqlite3
import os
import json
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import pandas as pd
from config import DATABASE_CONFIG

class DatabaseManager:
    def __init__(self, db_path: str = None):
        """初始化数据库管理器"""
        if db_path is None:
            db_path = os.path.join(DATABASE_CONFIG['sqlite']['path'], 
                                  DATABASE_CONFIG['sqlite']['database'])
        
        # 确保数据目录存在
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """初始化数据库表结构"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 创建帖子表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS posts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    zhihu_id TEXT UNIQUE NOT NULL,
                    title TEXT,
                    content TEXT,
                    author TEXT,
                    author_url TEXT,
                    publish_time DATETIME,
                    update_time DATETIME,
                    view_count INTEGER DEFAULT 0,
                    like_count INTEGER DEFAULT 0,
                    comment_count INTEGER DEFAULT 0,
                    share_count INTEGER DEFAULT 0,
                    topic TEXT,
                    crawl_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_negative BOOLEAN DEFAULT FALSE,
                    negative_category TEXT,
                    sentiment_score REAL DEFAULT 0.0
                )
            ''')
            
            # 创建评论表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS comments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    zhihu_id TEXT UNIQUE NOT NULL,
                    post_id TEXT NOT NULL,
                    parent_id TEXT,
                    content TEXT,
                    author TEXT,
                    author_url TEXT,
                    publish_time DATETIME,
                    like_count INTEGER DEFAULT 0,
                    reply_count INTEGER DEFAULT 0,
                    crawl_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_negative BOOLEAN DEFAULT FALSE,
                    negative_category TEXT,
                    sentiment_score REAL DEFAULT 0.0,
                    FOREIGN KEY (post_id) REFERENCES posts (zhihu_id)
                )
            ''')
            
            # 创建负面舆情统计表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS negative_statistics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,
                    post_count INTEGER DEFAULT 0,
                    comment_count INTEGER DEFAULT 0,
                    total_count INTEGER DEFAULT 0,
                    date DATE DEFAULT CURRENT_DATE,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建爬取任务表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS crawl_tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_type TEXT NOT NULL,  -- 'topic' or 'user'
                    target TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',  -- 'pending', 'running', 'completed', 'failed'
                    start_time DATETIME,
                    end_time DATETIME,
                    posts_count INTEGER DEFAULT 0,
                    comments_count INTEGER DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
    
    def insert_post(self, post_data: Dict) -> bool:
        """插入帖子数据"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO posts 
                    (zhihu_id, title, content, author, author_url, publish_time, 
                     update_time, view_count, like_count, comment_count, share_count, topic)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    post_data.get('zhihu_id'),
                    post_data.get('title'),
                    post_data.get('content'),
                    post_data.get('author'),
                    post_data.get('author_url'),
                    post_data.get('publish_time'),
                    post_data.get('update_time'),
                    post_data.get('view_count', 0),
                    post_data.get('like_count', 0),
                    post_data.get('comment_count', 0),
                    post_data.get('share_count', 0),
                    post_data.get('topic')
                ))
                conn.commit()
                return True
        except Exception as e:
            print(f"插入帖子数据失败: {e}")
            return False
    
    def insert_comment(self, comment_data: Dict) -> bool:
        """插入评论数据"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO comments 
                    (zhihu_id, post_id, parent_id, content, author, author_url, 
                     publish_time, like_count, reply_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    comment_data.get('zhihu_id'),
                    comment_data.get('post_id'),
                    comment_data.get('parent_id'),
                    comment_data.get('content'),
                    comment_data.get('author'),
                    comment_data.get('author_url'),
                    comment_data.get('publish_time'),
                    comment_data.get('like_count', 0),
                    comment_data.get('reply_count', 0)
                ))
                conn.commit()
                return True
        except Exception as e:
            print(f"插入评论数据失败: {e}")
            return False
    
    def update_post_sentiment(self, zhihu_id: str, is_negative: bool, 
                            negative_category: str, sentiment_score: float):
        """更新帖子情感分析结果"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE posts 
                    SET is_negative = ?, negative_category = ?, sentiment_score = ?
                    WHERE zhihu_id = ?
                ''', (is_negative, negative_category, sentiment_score, zhihu_id))
                conn.commit()
        except Exception as e:
            print(f"更新帖子情感分析失败: {e}")
    
    def update_comment_sentiment(self, zhihu_id: str, is_negative: bool, 
                               negative_category: str, sentiment_score: float):
        """更新评论情感分析结果"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE comments 
                    SET is_negative = ?, negative_category = ?, sentiment_score = ?
                    WHERE zhihu_id = ?
                ''', (is_negative, negative_category, sentiment_score, zhihu_id))
                conn.commit()
        except Exception as e:
            print(f"更新评论情感分析失败: {e}")
    
    def get_posts_by_topic(self, topic: str, limit: int = 100) -> List[Dict]:
        """根据主题获取帖子"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql_query('''
                    SELECT * FROM posts 
                    WHERE topic = ? 
                    ORDER BY publish_time DESC 
                    LIMIT ?
                ''', conn, params=(topic, limit))
                return df.to_dict('records')
        except Exception as e:
            print(f"获取主题帖子失败: {e}")
            return []
    
    def get_posts_by_user(self, author: str) -> List[Dict]:
        """根据用户获取帖子"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql_query('''
                    SELECT * FROM posts 
                    WHERE author = ? 
                    ORDER BY publish_time DESC
                ''', conn, params=(author,))
                return df.to_dict('records')
        except Exception as e:
            print(f"获取用户帖子失败: {e}")
            return []
    
    def get_comments_by_post(self, post_id: str) -> List[Dict]:
        """根据帖子ID获取评论"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql_query('''
                    SELECT * FROM comments 
                    WHERE post_id = ? 
                    ORDER BY publish_time ASC
                ''', conn, params=(post_id,))
                return df.to_dict('records')
        except Exception as e:
            print(f"获取帖子评论失败: {e}")
            return []
    
    def get_negative_posts(self, category: str = None) -> List[Dict]:
        """获取负面帖子"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                if category:
                    df = pd.read_sql_query('''
                        SELECT * FROM posts 
                        WHERE is_negative = TRUE AND negative_category = ?
                        ORDER BY publish_time DESC
                    ''', conn, params=(category,))
                else:
                    df = pd.read_sql_query('''
                        SELECT * FROM posts 
                        WHERE is_negative = TRUE
                        ORDER BY publish_time DESC
                    ''', conn)
                return df.to_dict('records')
        except Exception as e:
            print(f"获取负面帖子失败: {e}")
            return []
    
    def get_negative_comments(self, category: str = None) -> List[Dict]:
        """获取负面评论"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                if category:
                    df = pd.read_sql_query('''
                        SELECT * FROM comments 
                        WHERE is_negative = TRUE AND negative_category = ?
                        ORDER BY publish_time DESC
                    ''', conn, params=(category,))
                else:
                    df = pd.read_sql_query('''
                        SELECT * FROM comments 
                        WHERE is_negative = TRUE
                        ORDER BY publish_time DESC
                    ''', conn)
                return df.to_dict('records')
        except Exception as e:
            print(f"获取负面评论失败: {e}")
            return []
    
    def get_statistics(self) -> Dict:
        """获取统计数据"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # 总帖子数
                total_posts = pd.read_sql_query('SELECT COUNT(*) as count FROM posts', conn).iloc[0]['count']
                
                # 总评论数
                total_comments = pd.read_sql_query('SELECT COUNT(*) as count FROM comments', conn).iloc[0]['count']
                
                # 负面帖子数
                negative_posts = pd.read_sql_query('SELECT COUNT(*) as count FROM posts WHERE is_negative = TRUE', conn).iloc[0]['count']
                
                # 负面评论数
                negative_comments = pd.read_sql_query('SELECT COUNT(*) as count FROM comments WHERE is_negative = TRUE', conn).iloc[0]['count']
                
                # 按类别统计负面内容
                negative_by_category = pd.read_sql_query('''
                    SELECT negative_category, COUNT(*) as count 
                    FROM posts 
                    WHERE is_negative = TRUE 
                    GROUP BY negative_category
                ''', conn)
                
                return {
                    'total_posts': total_posts,
                    'total_comments': total_comments,
                    'negative_posts': negative_posts,
                    'negative_comments': negative_comments,
                    'negative_by_category': negative_by_category.to_dict('records')
                }
        except Exception as e:
            print(f"获取统计数据失败: {e}")
            return {}
    
    def export_to_csv(self, output_dir: str = './exports'):
        """导出数据到CSV文件"""
        try:
            os.makedirs(output_dir, exist_ok=True)
            
            with sqlite3.connect(self.db_path) as conn:
                # 导出帖子数据
                posts_df = pd.read_sql_query('SELECT * FROM posts', conn)
                posts_df.to_csv(os.path.join(output_dir, 'posts.csv'), index=False, encoding='utf-8-sig')
                
                # 导出评论数据
                comments_df = pd.read_sql_query('SELECT * FROM comments', conn)
                comments_df.to_csv(os.path.join(output_dir, 'comments.csv'), index=False, encoding='utf-8-sig')
                
                # 导出负面帖子数据
                negative_posts_df = pd.read_sql_query('SELECT * FROM posts WHERE is_negative = TRUE', conn)
                negative_posts_df.to_csv(os.path.join(output_dir, 'negative_posts.csv'), index=False, encoding='utf-8-sig')
                
                # 导出负面评论数据
                negative_comments_df = pd.read_sql_query('SELECT * FROM comments WHERE is_negative = TRUE', conn)
                negative_comments_df.to_csv(os.path.join(output_dir, 'negative_comments.csv'), index=False, encoding='utf-8-sig')
                
                print(f"数据已导出到 {output_dir} 目录")
        except Exception as e:
            print(f"导出数据失败: {e}") 