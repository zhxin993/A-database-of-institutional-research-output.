import requests
import time
import json
import re
from datetime import datetime
from typing import Dict, List, Optional
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from tqdm import tqdm
import random

from config import CRAWLER_CONFIG, ZHIHU_CONFIG, DATA_CONFIG
from database import DatabaseManager

class ZhihuCrawler:
    def __init__(self, use_selenium: bool = True):
        """初始化知乎爬虫"""
        self.use_selenium = use_selenium
        self.db = DatabaseManager()
        self.ua = UserAgent()
        self.session = requests.Session()
        
        # 设置请求头
        self.session.headers.update({
            'User-Agent': CRAWLER_CONFIG['user_agent'],
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
        
        # 初始化Selenium
        if self.use_selenium:
            self.init_selenium()
    
    def init_selenium(self):
        """初始化Selenium WebDriver"""
        try:
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument(f'--user-agent={CRAWLER_CONFIG["user_agent"]}')
            
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.implicitly_wait(10)
        except Exception as e:
            print(f"Selenium初始化失败: {e}")
            self.use_selenium = False
    
    def search_posts_by_topic(self, topic: str, max_posts: int = 100) -> List[Dict]:
        """根据主题搜索帖子"""
        print(f"开始搜索主题: {topic}")
        posts = []
        
        try:
            if self.use_selenium:
                posts = self._search_posts_selenium(topic, max_posts)
            else:
                posts = self._search_posts_requests(topic, max_posts)
            
            print(f"成功获取 {len(posts)} 个帖子")
            return posts
        except Exception as e:
            print(f"搜索帖子失败: {e}")
            return posts
    
    def _search_posts_selenium(self, topic: str, max_posts: int) -> List[Dict]:
        """使用Selenium搜索帖子"""
        posts = []
        page = 1
        
        try:
            while len(posts) < max_posts:
                # 构建搜索URL
                search_url = f"{ZHIHU_CONFIG['search_url']}?type=content&q={topic}&page={page}"
                self.driver.get(search_url)
                
                # 等待页面加载
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.CLASS_NAME, "Search-result"))
                )
                
                # 滚动页面加载更多内容
                self._scroll_page()
                
                # 解析帖子
                post_elements = self.driver.find_elements(By.CSS_SELECTOR, ".Search-result .ContentItem")
                
                for element in post_elements:
                    if len(posts) >= max_posts:
                        break
                    
                    try:
                        post_data = self._parse_post_element(element, topic)
                        if post_data:
                            posts.append(post_data)
                            self.db.insert_post(post_data)
                    except Exception as e:
                        print(f"解析帖子元素失败: {e}")
                        continue
                
                page += 1
                time.sleep(CRAWLER_CONFIG['delay'])
                
                # 检查是否还有更多页面
                if not self._has_next_page():
                    break
                    
        except Exception as e:
            print(f"Selenium搜索失败: {e}")
        
        return posts
    
    def _search_posts_requests(self, topic: str, max_posts: int) -> List[Dict]:
        """使用requests搜索帖子"""
        posts = []
        page = 1
        
        try:
            while len(posts) < max_posts:
                search_url = f"{ZHIHU_CONFIG['search_url']}?type=content&q={topic}&page={page}"
                
                response = self.session.get(search_url, timeout=CRAWLER_CONFIG['timeout'])
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                post_elements = soup.select(".Search-result .ContentItem")
                
                if not post_elements:
                    break
                
                for element in post_elements:
                    if len(posts) >= max_posts:
                        break
                    
                    try:
                        post_data = self._parse_post_soup(element, topic)
                        if post_data:
                            posts.append(post_data)
                            self.db.insert_post(post_data)
                    except Exception as e:
                        print(f"解析帖子元素失败: {e}")
                        continue
                
                page += 1
                time.sleep(CRAWLER_CONFIG['delay'])
                
        except Exception as e:
            print(f"Requests搜索失败: {e}")
        
        return posts
    
    def get_user_posts(self, username: str) -> List[Dict]:
        """获取用户的所有帖子"""
        print(f"开始获取用户 {username} 的帖子")
        posts = []
        
        try:
            if self.use_selenium:
                posts = self._get_user_posts_selenium(username)
            else:
                posts = self._get_user_posts_requests(username)
            
            print(f"成功获取用户 {username} 的 {len(posts)} 个帖子")
            return posts
        except Exception as e:
            print(f"获取用户帖子失败: {e}")
            return posts
    
    def _get_user_posts_selenium(self, username: str) -> List[Dict]:
        """使用Selenium获取用户帖子"""
        posts = []
        
        try:
            user_url = f"{ZHIHU_CONFIG['base_url']}/people/{username}/activities"
            self.driver.get(user_url)
            
            # 等待页面加载
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "ActivityItem"))
            )
            
            # 滚动加载更多内容
            self._scroll_page()
            
            # 解析帖子
            post_elements = self.driver.find_elements(By.CSS_SELECTOR, ".ActivityItem")
            
            for element in post_elements:
                try:
                    post_data = self._parse_user_post_element(element, username)
                    if post_data:
                        posts.append(post_data)
                        self.db.insert_post(post_data)
                except Exception as e:
                    print(f"解析用户帖子元素失败: {e}")
                    continue
                    
        except Exception as e:
            print(f"Selenium获取用户帖子失败: {e}")
        
        return posts
    
    def _get_user_posts_requests(self, username: str) -> List[Dict]:
        """使用requests获取用户帖子"""
        posts = []
        
        try:
            user_url = f"{ZHIHU_CONFIG['base_url']}/people/{username}/activities"
            response = self.session.get(user_url, timeout=CRAWLER_CONFIG['timeout'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            post_elements = soup.select(".ActivityItem")
            
            for element in post_elements:
                try:
                    post_data = self._parse_user_post_soup(element, username)
                    if post_data:
                        posts.append(post_data)
                        self.db.insert_post(post_data)
                except Exception as e:
                    print(f"解析用户帖子元素失败: {e}")
                    continue
                    
        except Exception as e:
            print(f"Requests获取用户帖子失败: {e}")
        
        return posts
    
    def get_post_comments(self, post_id: str, max_comments: int = 1000) -> List[Dict]:
        """获取帖子的评论和回复"""
        print(f"开始获取帖子 {post_id} 的评论")
        comments = []
        
        try:
            if self.use_selenium:
                comments = self._get_comments_selenium(post_id, max_comments)
            else:
                comments = self._get_comments_requests(post_id, max_comments)
            
            print(f"成功获取帖子 {post_id} 的 {len(comments)} 条评论")
            return comments
        except Exception as e:
            print(f"获取评论失败: {e}")
            return comments
    
    def _get_comments_selenium(self, post_id: str, max_comments: int) -> List[Dict]:
        """使用Selenium获取评论"""
        comments = []
        
        try:
            post_url = f"{ZHIHU_CONFIG['base_url']}/question/{post_id}"
            self.driver.get(post_url)
            
            # 等待评论区域加载
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "CommentItem"))
            )
            
            # 滚动加载更多评论
            self._scroll_page()
            
            # 解析评论
            comment_elements = self.driver.find_elements(By.CSS_SELECTOR, ".CommentItem")
            
            for element in comment_elements:
                if len(comments) >= max_comments:
                    break
                
                try:
                    comment_data = self._parse_comment_element(element, post_id)
                    if comment_data:
                        comments.append(comment_data)
                        self.db.insert_comment(comment_data)
                except Exception as e:
                    print(f"解析评论元素失败: {e}")
                    continue
                    
        except Exception as e:
            print(f"Selenium获取评论失败: {e}")
        
        return comments
    
    def _get_comments_requests(self, post_id: str, max_comments: int) -> List[Dict]:
        """使用requests获取评论"""
        comments = []
        
        try:
            post_url = f"{ZHIHU_CONFIG['base_url']}/question/{post_id}"
            response = self.session.get(post_url, timeout=CRAWLER_CONFIG['timeout'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            comment_elements = soup.select(".CommentItem")
            
            for element in comment_elements:
                if len(comments) >= max_comments:
                    break
                
                try:
                    comment_data = self._parse_comment_soup(element, post_id)
                    if comment_data:
                        comments.append(comment_data)
                        self.db.insert_comment(comment_data)
                except Exception as e:
                    print(f"解析评论元素失败: {e}")
                    continue
                    
        except Exception as e:
            print(f"Requests获取评论失败: {e}")
        
        return comments
    
    def _parse_post_element(self, element, topic: str) -> Optional[Dict]:
        """解析帖子元素（Selenium）"""
        try:
            # 提取帖子ID
            post_link = element.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
            post_id = re.search(r'/question/(\d+)', post_link)
            if not post_id:
                return None
            post_id = post_id.group(1)
            
            # 提取标题
            title_element = element.find_element(By.CSS_SELECTOR, "h2")
            title = title_element.text.strip() if title_element else ""
            
            # 提取内容
            content_element = element.find_element(By.CSS_SELECTOR, ".RichContent-inner")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            author_element = element.find_element(By.CSS_SELECTOR, ".UserLink")
            author = author_element.text.strip() if author_element else ""
            author_url = author_element.get_attribute("href") if author_element else ""
            
            # 提取统计信息
            stats = self._extract_post_stats(element)
            
            return {
                'zhihu_id': post_id,
                'title': title,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'update_time': datetime.now().isoformat(),
                'view_count': stats.get('view_count', 0),
                'like_count': stats.get('like_count', 0),
                'comment_count': stats.get('comment_count', 0),
                'share_count': stats.get('share_count', 0),
                'topic': topic
            }
        except Exception as e:
            print(f"解析帖子元素失败: {e}")
            return None
    
    def _parse_post_soup(self, element, topic: str) -> Optional[Dict]:
        """解析帖子元素（BeautifulSoup）"""
        try:
            # 提取帖子ID
            post_link = element.select_one("a")
            if not post_link:
                return None
            post_href = post_link.get("href", "")
            post_id = re.search(r'/question/(\d+)', post_href)
            if not post_id:
                return None
            post_id = post_id.group(1)
            
            # 提取标题
            title_element = element.select_one("h2")
            title = title_element.text.strip() if title_element else ""
            
            # 提取内容
            content_element = element.select_one(".RichContent-inner")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            author_element = element.select_one(".UserLink")
            author = author_element.text.strip() if author_element else ""
            author_url = author_element.get("href", "") if author_element else ""
            
            # 提取统计信息
            stats = self._extract_post_stats_soup(element)
            
            return {
                'zhihu_id': post_id,
                'title': title,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'update_time': datetime.now().isoformat(),
                'view_count': stats.get('view_count', 0),
                'like_count': stats.get('like_count', 0),
                'comment_count': stats.get('comment_count', 0),
                'share_count': stats.get('share_count', 0),
                'topic': topic
            }
        except Exception as e:
            print(f"解析帖子元素失败: {e}")
            return None
    
    def _parse_comment_element(self, element, post_id: str) -> Optional[Dict]:
        """解析评论元素（Selenium）"""
        try:
            # 提取评论ID
            comment_id = element.get_attribute("data-comment-id")
            if not comment_id:
                return None
            
            # 提取内容
            content_element = element.find_element(By.CSS_SELECTOR, ".CommentItemV2-content")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            author_element = element.find_element(By.CSS_SELECTOR, ".CommentItemV2-meta .UserLink")
            author = author_element.text.strip() if author_element else ""
            author_url = author_element.get_attribute("href") if author_element else ""
            
            # 提取父评论ID
            parent_id = element.get_attribute("data-parent-id")
            
            # 提取统计信息
            like_element = element.find_element(By.CSS_SELECTOR, ".CommentItemV2-footer .VoteButton")
            like_count = int(like_element.text.strip()) if like_element else 0
            
            return {
                'zhihu_id': comment_id,
                'post_id': post_id,
                'parent_id': parent_id,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'like_count': like_count,
                'reply_count': 0
            }
        except Exception as e:
            print(f"解析评论元素失败: {e}")
            return None
    
    def _parse_comment_soup(self, element, post_id: str) -> Optional[Dict]:
        """解析评论元素（BeautifulSoup）"""
        try:
            # 提取评论ID
            comment_id = element.get("data-comment-id")
            if not comment_id:
                return None
            
            # 提取内容
            content_element = element.select_one(".CommentItemV2-content")
            content = content_element.text.strip() if content_element else ""
            
            # 提取作者信息
            author_element = element.select_one(".CommentItemV2-meta .UserLink")
            author = author_element.text.strip() if author_element else ""
            author_url = author_element.get("href", "") if author_element else ""
            
            # 提取父评论ID
            parent_id = element.get("data-parent-id")
            
            # 提取统计信息
            like_element = element.select_one(".CommentItemV2-footer .VoteButton")
            like_count = int(like_element.text.strip()) if like_element else 0
            
            return {
                'zhihu_id': comment_id,
                'post_id': post_id,
                'parent_id': parent_id,
                'content': content,
                'author': author,
                'author_url': author_url,
                'publish_time': datetime.now().isoformat(),
                'like_count': like_count,
                'reply_count': 0
            }
        except Exception as e:
            print(f"解析评论元素失败: {e}")
            return None
    
    def _extract_post_stats(self, element) -> Dict:
        """提取帖子统计信息（Selenium）"""
        stats = {}
        try:
            # 提取浏览量
            view_element = element.find_element(By.CSS_SELECTOR, ".ContentItem-meta .ContentItem-status")
            if view_element:
                view_text = view_element.text.strip()
                view_count = re.search(r'(\d+)', view_text)
                if view_count:
                    stats['view_count'] = int(view_count.group(1))
            
            # 提取点赞数
            like_element = element.find_element(By.CSS_SELECTOR, ".VoteButton")
            if like_element:
                like_text = like_element.text.strip()
                like_count = re.search(r'(\d+)', like_text)
                if like_count:
                    stats['like_count'] = int(like_count.group(1))
            
            # 提取评论数
            comment_element = element.find_element(By.CSS_SELECTOR, ".ContentItem-actions .Button")
            if comment_element:
                comment_text = comment_element.text.strip()
                comment_count = re.search(r'(\d+)', comment_text)
                if comment_count:
                    stats['comment_count'] = int(comment_count.group(1))
        except Exception as e:
            print(f"提取统计信息失败: {e}")
        
        return stats
    
    def _extract_post_stats_soup(self, element) -> Dict:
        """提取帖子统计信息（BeautifulSoup）"""
        stats = {}
        try:
            # 提取浏览量
            view_element = element.select_one(".ContentItem-meta .ContentItem-status")
            if view_element:
                view_text = view_element.text.strip()
                view_count = re.search(r'(\d+)', view_text)
                if view_count:
                    stats['view_count'] = int(view_count.group(1))
            
            # 提取点赞数
            like_element = element.select_one(".VoteButton")
            if like_element:
                like_text = like_element.text.strip()
                like_count = re.search(r'(\d+)', like_text)
                if like_count:
                    stats['like_count'] = int(like_count.group(1))
            
            # 提取评论数
            comment_element = element.select_one(".ContentItem-actions .Button")
            if comment_element:
                comment_text = comment_element.text.strip()
                comment_count = re.search(r'(\d+)', comment_text)
                if comment_count:
                    stats['comment_count'] = int(comment_count.group(1))
        except Exception as e:
            print(f"提取统计信息失败: {e}")
        
        return stats
    
    def _scroll_page(self):
        """滚动页面加载更多内容"""
        try:
            last_height = self.driver.execute_script("return document.body.scrollHeight")
            while True:
                # 滚动到底部
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)
                
                # 计算新的滚动高度
                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    break
                last_height = new_height
        except Exception as e:
            print(f"滚动页面失败: {e}")
    
    def _has_next_page(self) -> bool:
        """检查是否有下一页"""
        try:
            next_button = self.driver.find_element(By.CSS_SELECTOR, ".Pagination-next")
            return next_button.is_enabled()
        except:
            return False
    
    def close(self):
        """关闭爬虫"""
        if hasattr(self, 'driver'):
            self.driver.quit()
        self.session.close() 